var version='6.3.0.3';
self.addEventListener('install',function(ev){
	ev.waitUntil(caches.open('lr-cache-v'+version).then(function(cache){
		if(location.protocol=='http:'||location.protocol=='https:'){
			return fetch('/resource.json').then(function(res){
				return res.json();
			}).then(function(files){
				return cache.addAll(files);
			});
		}
	}));
	self.skipWaiting();
});
self.addEventListener('activate',function(ev){
	ev.waitUntil(caches.keys().then(function(keyList){
		return Promise.all(keyList.map(function(key){
			if('lr-cache-v'+version!=key){
				return caches.delete(key);
			}
		}));
	}));
});
self.addEventListener('fetch',function(ev){
	ev.respondWith(caches.match(ev.request).then(function(res){
		return res||fetch(ev.request).then(function(res){
			var resToCache=res.clone(),
				newHeaders=new Headers(resToCache.headers),
				exp=new Date();
			exp.setMonth(exp.getMonth()+1);
			newHeaders.set('Expires',exp.toUTCString());
			newHeaders.set('Cache-Control','public,max-age=31536000');
			newHeaders.append('X-Powered-By','ServiceWorker');
			if(resToCache.status==200){
				var anotherResponse=new Response(resToCache.body,{
						status:resToCache.status,
						statusText:resToCache.statusText,
						headers:newHeaders
					});
				caches.open('lr-cache-v'+version).then(function(cache){
					var url=new URL(ev.request.url);
					if(ev.request.method=='GET'&&(url.protocol=='http:'||url.protocol=='https:')&&url.host==location.host){
						cache.put(ev.request,anotherResponse);
					}
				});
			}
			return res;
		}).catch(function(res){
			return caches.match('/offline.html');
		});
	}));
});
