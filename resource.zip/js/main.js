;'use strict';!
(function(){
	var expand,
		stopGo,
		loader;
	function authFb(ev){
		//alert('fb');
	}
	function authGo(ev){
		//alert('go');
	}
	function encode(s){
		return s.replace(/&/g,"&amp;").replace(/>/g,"&gt;").replace(/</g,"&lt;").replace(/"/g,"&quot;");
	}
	function decode(s){
		return s.replace(/&amp;/g,"&").replace(/>/g,">").replace(/&lt;/g,"<").replace(/&quot;/g,'"');
	}
	function validURL(url){
		var pattern = new RegExp('^(https?:\\/\\/)?((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|((\\d{1,3}\\.){3}\\d{1,3}))(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*(\\?[;&a-z\\d%_.~+=-]*)?(\\#[-a-z\\d_]*)?$','i');
		return !!pattern.test(url);
	}
	function getTranslations(msgId){
		if(typeof chrome!='undefined'&&typeof chrome.i18n!='undefined'&&chrome.i18n.getMessage!='undefined'&&chrome.i18n.getMessage('language')!=undefined)
			return chrome.i18n.getMessage(msgId)||'';
		else
			return configs.translations[msgId]?configs.translations[msgId].message:'';
	}
	function getIndexBlock(blockId,json){
		json=json||JSON.parse(localStorage.dataBoard);
		for(var i=0;i<json.blocks.length;i++)
			if(json.blocks[i]['id']==blockId)
				return i;
	}
	function getIndexLink(indexBlock,index,json){
		json=json||JSON.parse(localStorage.dataBoard);
		for(var i=0;i<json.blocks[indexBlock].links.length;i++)
			if(i==index)
				return i;
	}
	function getManifest(){
		if(chrome.runtime){
			if(chrome.runtime.getManifest){
				configs.manifestExt=chrome.runtime.getManifest();
				jsl(configs.ids.topNav).children('.v').html('v'+configs.manifestExt.version);
				vVision(configs.manifestExt.version);
				return;
			}
		}
		jsl.ajax({
			url:configs.domain+'/resource/manifest.json',
			type:'POST',
			4:function(res){
				try{
					configs.manifestExt=JSON.parse(res.response);
					jsl(configs.ids.topNav).children('.v').html('v'+configs.manifestExt.version);
					vVision(configs.manifestExt.version);
				}catch(e){}
			}
		});
	}
	function vVision(mv){
		if(localStorage.appVersion){
			if(localStorage.appVersion!=mv){
				clearCash();
				notificationShow(getTranslations('transLoadingNewVersion')||'<img height="10" width="10" src="/img/load.gif">&nbsp;Loading a new version of the application.','warning');
				if(configs.manifestExt.version_name.split(' ')[1]=='critical'){
					loader.start();
					setTimeout(function(){
						location.reload();
					},3e3);
				}
				if(configs.manifestExt.version_name.split(' ')[1]=='uncritical'){
					setTimeout(function(){
						notificationShow(getTranslations('transLoadedNewVersion')||'Application updated. Refresh the page to apply the new version.','warning');
					},3e3);
				}
				
			}
		}else{
			localStorage.appVersion=String(mv);
		}
	}
	function clearCash(fn){
		localStorage.clear();
		navigator.serviceWorker.getRegistrations().then(function(registrations){
			caches.keys().then(function(keyList){
				return Promise.all(keyList.map(function(key){
					return caches.delete(key);
				}));
			});
			for(var registration of registrations){
				registration.unregister();
			}
		});
		caches.delete(configs.manifestExt.version).then(function(boolean){
			if(typeof fn=='function'){
				fn();
			}
		});
	}
	function clearSess(){
		var cookies=document.cookie.split(';');
		localStorage.clear();
		for(var i=0;i<cookies.length;i++){
			var cookie=cookies[i],
				eqPos=cookie.indexOf('='),
				name=eqPos>-1?cookie.substr(0,eqPos):cookie;
			document.cookie=name+'=;path=/;expires='+new Date(0).toUTCString();
		}
		fetch(configs.domain+'/at.json?session_destroy=1').then(function(){
			location.reload();
		});
	}
	function saveHtml(){
		var clone=document.cloneNode(true);
		try{
			clone.querySelectorAll('.summary')[0].style.color='';
			clone.querySelectorAll('.summary')[0].className='summary material-icons gear';
			clone.querySelectorAll('.menu')[0].style.display='none';
		}catch(e){}
		return localStorage.data=clone.querySelectorAll(configs.ids.blank)[0].innerHTML;
	}
	function expandFn(){
		var div=jsl('div').createElement({style:'overflow:scroll;width:50px;height:50px'}),
			div1=jsl('div').createElement({style:'width:100px;height:100px'});
		jsl(div).append(div1);
		jsl('body').append(div);
		expand=window.innerWidth-document.documentElement.clientWidth||window.innerWidth-document.body.offsetWidth||jsl(div).offsetWidth-jsl(div).clientWidth;
		jsl('body').remove(div);
	}
	function translateNodes(lang){
		var tl=document.querySelectorAll('[data-tl]'),
			language,
			transform=0;
		if(typeof chrome!='undefined'&&typeof chrome.i18n!='undefined'&&chrome.i18n.getMessage!='undefined'&&chrome.i18n.getMessage('language')!=undefined){
			for(var i=0;i<tl.length;i++){
				var tl1=tl[i].getAttribute('data-tl'),
					hasTarget=tl1.indexOf(':')>0,
					target=hasTarget?tl1.split(':')[0]:'',
					msgId=hasTarget?tl1.split(':')[1]:tl1,
					message=chrome.i18n.getMessage(msgId);
				if(message!=undefined&&message!=''){
					switch(target){
						case'html':
							tl[i].innerHTML=message;
						break;
						case'':
						case'text':
							tl[i].textContent=message;
						break;
						default:
							tl[i].setAttribute(target,message);
					}
				}
			}
			language=chrome.i18n.getUILanguage();
			jsl('html').attr('lang',chrome.i18n.getMessage('language')||language);
			jsl(configs.ids.topNav).children('.langs').val(language);
			if(language=='ar'||language=='fa'||language=='he')
				transform=180;
			jsl(configs.ids.blank).css('transform','rotateY('+transform+'deg)');
			try{
				jsl(configs.ids.topNav).children('.search').eq(0).prop('placeholder',getTranslations('transSearchInputPlac')+' '+(getTranslations('transSearchInputPlac')&&jsl(configs.ids.topNav).children('.searchservice').eq(0).children('option').eq(jsl(configs.ids.topNav).children('.searchservice').eq(0).prop('selectedIndex')).html()));
			}catch(e){}
		}else{
			if(lang==undefined){
				if(localStorage.dataBoard){
					var json=JSON.parse(localStorage.dataBoard);
					language=json.lang;
				}
				if(language==undefined){
					var language=window.navigator?(window.navigator.language||window.navigator.systemLanguage||window.navigator.userLanguage):'en-us';
					language=language.substr(0,2).toLowerCase();
				}
			}else
				language=lang;
			jsl('html').attr('lang',language);
			jsl(configs.ids.topNav).children('.langs').val(language);
			if(language=='ar'||language=='fa'||language=='he')
				transform=180;
			jsl(configs.ids.blank).css('transform','rotateY('+transform+'deg)');
			jsl(configs.ids.topNav).children('.langs').css('display','inline-block');
			jsl('.langs').on('change',function(ev){
				changeLang(ev.target,false);
			});
			jsl('.langs').on('blur',function(ev){
				blurCon(ev.target.value,'changeLang');
			});
			fetch('/_locales/'+language+'/messages.json',{
				cache:'no-store'
			}).then(function(res){
				return res.json();
			}).then(function(res){
				var translations=res;
				configs.translations=translations;
				if(translations['fullLanguage']){
					if(translations['fullLanguage']['message']!=''){
						jsl('html').attr('lang',translations['language']['message']);
					}
				}
				for(var i=0;i<tl.length;i++){
					var tl1=tl[i].getAttribute('data-tl'),
						hasTarget=tl1.indexOf(':')>0,
						target=hasTarget?tl1.split(':')[0]:'',
						msgId=hasTarget?tl1.split(':')[1]:tl1,
						message=configs.translations[msgId];
					if(!message||message.message=='')
						continue;
					switch(target){
						case'html':
							tl[i].innerHTML=message.message;
						break;
						case'':
						case'text':
							tl[i].textContent=message.message;
						break;
						default:
							tl[i].setAttribute(target,message.message);
					}
				}
				try{
					jsl(configs.ids.topNav).children('.search').eq(0).prop('placeholder',getTranslations('transSearchInputPlac')+' '+(getTranslations('transSearchInputPlac')&&jsl(configs.ids.topNav).children('.searchservice').eq(0).children('option').eq(jsl(configs.ids.topNav).children('.searchservice').eq(0).prop('selectedIndex')).html()));
				}catch(e){}
			});
		}
	}
	function translateStr(html){
		var wrap=document.createElement('div');
		wrap.innerHTML=html;
		var tl=wrap.querySelectorAll('[data-tl]');
		if(typeof chrome!='undefined'&&typeof chrome.i18n!='undefined'&&chrome.i18n.getMessage!='undefined'&&chrome.i18n.getMessage('language')!=undefined){
			for(var i=0;i<tl.length;i++){
				var tl1=tl[i].getAttribute('data-tl'),
					hasTarget=tl1.indexOf(':')>0,
					target=hasTarget?tl1.split(':')[0]:'',
					msgId=hasTarget?tl1.split(':')[1]:tl1,
					message=chrome.i18n.getMessage(msgId);
				if(message!=undefined&&message!=''&&message!='undefined'){
					switch(target){
						case'html':
							tl[i].innerHTML=message;
						break;
						case'':
						case'text':
							tl[i].textContent=message;
						break;
						default:
							tl[i].setAttribute(target,message);
					}
				}
			}
		}else{
			for(var i=0;i<tl.length;i++){
				var tl1=tl[i].getAttribute('data-tl'),
					hasTarget=tl1.indexOf(':')>0,
					target=hasTarget?tl1.split(':')[0]:'',
					msgId=hasTarget?tl1.split(':')[1]:tl1;
				if(configs.translations[msgId]){
					var message=configs.translations[msgId].message;
					if(message!=undefined&&message!=''&&message!='undefined'){
						switch(target){
							case'html':
								tl[i].innerHTML=message;
							break;
							case'':
							case'text':
								tl[i].textContent=message;
							break;
							default:
								tl[i].setAttribute(target,message);
						}
					}
				}
			}
		}
		return html?wrap.innerHTML:undefined;
	}
	function searchJson(string,json){
		var result={},
			json=json||JSON.parse(localStorage.dataBoard),
			linkBlock=jsl('div').createElement({
				class:'wrap-search-block'
			}),
			result={
				links:[],
				blocks:[],
				countColum:json.countColum,
				columMinWid:json.columMinWid,
				timestamp:json.timestamp,
				data:json.data,
				dragPoint:json.dragPoint
			};
		if(string!=''){
			jsl('.search-block .cancel').css('visibility','visible');
			for(var i=0;i<json.blocks.length;i++){
				if(result.blocks.indexOf(i)==-1){
					if(json.blocks[i].title.toLowerCase().indexOf(string.toLowerCase())!=-1)
						if(result.blocks.indexOf(i)==-1)
							result.blocks.push(json.blocks[i]);
					for(var j=0;j<json.blocks[i].links.length;j++){
						if(json.blocks[i].links[j].href.toLowerCase().indexOf(string.toLowerCase())!=-1||json.blocks[i].links[j].html.toLowerCase().indexOf(string.toLowerCase())!=-1){
							if(result.blocks.indexOf(json.blocks[i])==-1)
								result.blocks.push(json.blocks[i]);
							if(result.links.indexOf(json.blocks[i].links[j])==-1)
								result.links.push(json.blocks[i].links[j]);
						}
					}
				}
			}
		}else{
			jsl('.search-block .cancel').css('visibility','hidden');
			result=json;
		}
		renderDashboard(result);
		resizeDashboard(result);
		if(result.links!=undefined){
			for(var k=0;k<result.links.length;k++){
				var linkA=jsl('a').createElement({
						class:'link',
						'data-num':'link-'+k,
						rel:'nofollow',
						href:result.links[k]['href'],
						title:(result.links[k]['title']||getTranslations('transEditThisLink')||'New bookmark')+' | '+result.links[k]['href']
					}).on('mouseenter',function(){
						var json=json||JSON.parse(localStorage.dataBoard);
						json.showTooltip==true&&jsl(configs.ids.windowTooltip).html(this.attr('title')).addClass('show');
					}).on('mouseleave',function(){
						jsl(configs.ids.windowTooltip).removeClass('show');
					}),
					nameSpan=jsl('span').createElement().html(result.links[k]['html']||getTranslations('transEditThisLink')||'New bookmark'),
					parsUrl=jsl.parserUrl(result.links[k]['href']),
					faviconImg=jsl('img').createElement({
						src:result.links[k]['favicon_url']?result.links[k]['favicon_url']:configs.domain+'/favicon.png?url='+parsUrl.protocol+'//'+parsUrl.host,
						alt:(result.links[k]['title']||getTranslations('transEditThisLink')||'New bookmark')+' | '+result.links[k]['href'],
						title:(result.links[k]['title']||getTranslations('transEditThisLink')||'New bookmark')+' | '+result.links[k]['href'],
						height:'16',
						width:'16',
						loading:'lazy'
					}).on('error',function(ev){
						ev.target.src=json.theme?translateStr(configs.html.errorFaviconDark):translateStr(configs.html.errorFavicon);
					}),
					wrapLinkSpan=jsl('span').createElement({
						class:'wrap-link-span',
						'data-num':'wrap-link-'+k
					});
				linkA.append(faviconImg).append(nameSpan);
				wrapLinkSpan.append(linkA);
				linkBlock.append(wrapLinkSpan);
			}
			var html=linkBlock.a.outerHTML+jsl(configs.ids.body).html();
			var emptySearch=jsl('div').createElement({
				class:'empty',
				tl:'transEmpty'
			}).html(translateStr(configs.html.emptySearch)||'Empty');
			jsl(configs.ids.body).html(result.links.length==0&&result.blocks.length==0&&linkBlock.html()==''?emptySearch.a.outerHTML:html);
		}
	}
	function editLink(el,json){
		var blockId=/block-(\d+)/.exec(jsl(el).attr('data-num-block'))[1],
			linkId=/link-(\d+)/.exec(jsl(el).attr('data-num-link'))[1],
			json=json||JSON.parse(localStorage.dataBoard),
			selector='.input-block-wrap[data-num=input-'+blockId+']',
			inputBlockBack=jsl('div').createElement({
				class:'input-block-back',
				'data-num':'input-block-back-'+linkId
			}),
			winp=jsl('div').createElement({
				class:'input-block-wrap',
				'data-num':'input-'+blockId
			}),
			newUrl=jsl('input').createElement({
				'data-num-block':blockId,
				'data-num-link':linkId,
				class:'input',
				name:'link-url',
				tl:'placeholder:transEnterUrl',
				placeholder:getTranslations('transEnterUrl')||'Enter Url'
			}).val(jsl('.block[data-num='+blockId+'] a[data-num='+linkId+']').attr('href')),
			clAdd=jsl('img').createElement({
				class:'close',
				tl:'title:transCancel',
				alt:getTranslations('transCancel')||'Cancel',
				title:getTranslations('transCancel')||'Cancel',
				tl:'title:transCancel',
				src:json.theme?translateStr(configs.html.closeIconDark):translateStr(configs.html.closeIcon),
				'data-num':'close-'+linkId,
				height:'16',
				width:'16'
			}).prop({
				ini:linkId,
				inb:blockId
			}).on('mousedown',function(ev){
				ev.preventDefault();
				return false;
			}),
			startEdit=function(ev){
				if(ev.keyCode==13){
					var el=ev.target;
					if(configs.temp.editLinkNew==undefined){
						configs.temp.editLinkNew={};
					}
					if(configs.temp.editLinkNew.url==undefined){
						configs.temp.editLinkNew.url=el.value.toLowerCase();
					}
					if(configs.temp.editLinkNew.url&&configs.temp.editLinkNew.favicon===undefined){
						configs.temp.editLinkNew.favicon=null;
						jsl(el).on('blur').attr('readonly','readonly').css('cursor','not-allowed');
						jsl('.input-block-back').css('display','block');
						jsl(selector+' img').attr('src','/img/load.gif');
						jsl(selector).css('margin','0px 30px 0px 0px');
						jsl(selector+' img').css('display','block');
						fetch(configs.domain+'/favicon.png?source=xtn-chrome&url='+configs.temp.editLinkNew.url).then(function(res){
							return res.json();
						}).then(function(res){
							configs.temp.editLinkNew.favicon=res.favicon_data_url||res.favicon_url||configs.html.favicon;
							startEdit(ev);
						}).catch(function(){
							configs.temp.editLinkNew.favicon=configs.html.favicon;
							startEdit(ev);
						});
					}
					if(configs.temp.editLinkNew.url&&configs.temp.editLinkNew.title===undefined){
						configs.temp.editLinkNew.title=null;
						jsl(el).on('blur').attr('readonly','readonly').css('cursor','not-allowed');
						jsl('.input-block-back').css('display','block');
						jsl(selector+' img').attr('src','/img/load.gif');
						jsl(selector).css('margin','0px 30px 0px 0px');
						jsl(selector+' img').css('display','block');
						jsl.ajax({
							url:configs.domain+'/gt.html',
							type:'POST',
							headers:{
								'Content-Type':'application/x-www-form-urlencoded',
							},
							4:function(res){
								var match=res.response.match(/<title.*?>(.+)<\/title>/),
									title=res.response==''||res.status!=200||match==null?'New bookmark':match[1].trim();
								title=title==''?'New bookmark':title;
								configs.temp.editLinkNew.title=title;
								startEdit(ev);
							}
						},{
							url:configs.temp.editLinkNew.url,
							hl:configs.lang
						});
					}
					if(configs.temp.editLinkNew.done){
						configs.temp.editLinkNew.title=el.value;
						el.blur();
						return;
					}
					if(
						configs.temp.editLinkNew.url&&
						configs.temp.editLinkNew.title&&
						configs.temp.editLinkNew.favicon
					){
						stopGo=false;
						jsl(el).attr({
							placeholder:getTranslations('transEnterName')||'Enter Name',
							tl:'placeholder:transEnterName'
						}).val(configs.temp.editLinkNew.title).on('focus').removeAttribute('readonly').css('cursor','auto').select();
						jsl('.input-block-back').css('display','none');
						jsl(selector+' img').attr('src','/img/load.gif');
						jsl(selector+' img').css('display','none');
						jsl(selector).css('margin','0');
						configs.temp.editLinkNew.done=true;
						el.addEventListener('blur',function(){
							configs.temp.editLinkNew.title=el.value;
							
							json.blocks[getIndexBlock(blockId,json)]['links'][linkId]={
								href:configs.temp.editLinkNew.url,
								html:configs.temp.editLinkNew.title,
								title:configs.temp.editLinkNew.title,
								favicon_url:configs.temp.editLinkNew.favicon,
							};
							notificationShow(getTranslations('transBookmarkSaved')||'Bookmark saved.','message');
							setTimeout(function(){stopGo=true;},100);
							updateData(json,{
								href:configs.temp.editLinkNew.url,
								html:configs.temp.editLinkNew.title,
								title:configs.temp.editLinkNew.title,
								parentBlock:blockId,
								linkId:linkId
							},'editLink');
							delete configs.temp.editLinkNew;
						},false);
						jsl.ajax({
							url:configs.domain+'/ss.json',
							type:'POST',
							headers:{
								'Content-Type':'application/x-www-form-urlencoded',
							}
						},{
							url:configs.temp.editLinkNew.url
						});
					}
					ev.preventDefault();
					return false;
				}
			},
			endEdit=function(ev){
				if(ev.keyCode==27){
					clAdd.a.click();
					ev.preventDefault();
					return false;
				}
			};
		stopGo=false;
		winp.append(newUrl).append(clAdd);
		jsl('.block[data-num=block-'+blockId+'] .wrap-link-span[data-num=wrap-link-'+linkId+']').append(inputBlockBack).append(winp);
		
		jsl('.input-block-back').css('display','none');
		jsl('.block[data-num=block-'+blockId+'] a[data-num=link-'+linkId+']').css('display','none');
		jsl('.block[data-num=block-'+blockId+'] img[data-num-link=link-'+linkId+']').css('display','none');
		jsl('.block[data-num=block-'+blockId+'] img[data-num=link-'+linkId+']').css('display','none');
		clAdd.a.addEventListener('click',function(ev){
			setTimeout(function(){stopGo=true;},100);
			loader.stop();
			jsl('.input-block-wrap[data-num=input-'+this.inb+']').css('display','none');
			jsl('.block[data-num=block-'+this.inb+'] a[data-num=link-'+this.ini+']').css('display','block');
			jsl('.block[data-num=block-'+this.inb+'] img[data-num-link=link-'+this.ini+']').css('display','');
			jsl('.block[data-num=block-'+this.inb+'] img[data-num=link-'+this.ini+']').css('display','block');
		});
		newUrl.val(json.blocks[getIndexBlock(blockId,json)].links[linkId].href);
		newUrl.on('focus');
		newUrl.a.onkeyup=startEdit;
		newUrl.a.onkeydown=endEdit;
		newUrl.a.select();
	}
	function addLink(el,json){
		var selector='.input-block-wrap[data-num=input-block-wrap-'+/input-block-wrap-(\d+)/.exec(jsl(el).parent().attr('data-num'))[1]+']';
		if(configs.temp.addLink==undefined){
			configs.temp.addLink={};
		}
		if(configs.temp.addLink.url==undefined){
			configs.temp.addLink.url=el.value.toLowerCase();
		}
		if(configs.temp.addLink.url&&configs.temp.addLink.favicon===undefined){
			configs.temp.addLink.favicon=null;
			jsl(el).on('blur').attr('readonly','readonly').css('cursor','not-allowed');
			jsl('.input-block-back').css('display','block');
			jsl(selector+' img').attr('src','/img/load.gif');
			jsl(selector).css('margin','0px 30px 0px 0px');
			jsl(selector+' img').css('display','block');
			jsl(el.inb).css('display','block');
			fetch(configs.domain+'/favicon.png?source=xtn-chrome&url='+configs.temp.addLink.url).then(function(res){
				return res.json();
			}).then(function(res){
				configs.temp.addLink.favicon=res.favicon_data_url||res.favicon_url||configs.html.favicon;
				addLink(el,json);
			}).catch(function(){
				configs.temp.addLink.favicon=configs.html.favicon;
				addLink(el,json);
			});
		}
		if(configs.temp.addLink.url&&configs.temp.addLink.title===undefined){
			configs.temp.addLink.title=null;
			jsl(el).on('blur').attr('readonly','readonly').css('cursor','not-allowed');
			jsl('.input-block-back').css('display','block');
			jsl(selector+' img').attr('src','/img/load.gif');
			jsl(selector).css('margin','0px 30px 0px 0px');
			jsl(selector+' img').css('display','block');
			jsl(el.inb).css('display','block');
			jsl.ajax({
				url:configs.domain+'/gt.html',
				type:'POST',
				headers:{
					'Content-Type':'application/x-www-form-urlencoded',
				},
				4:function(res){
					var match=res.response.match(/<title.*?>(.+)<\/title>/),
						title=res.response==''||res.status!=200||match==null?'New bookmark':match[1].trim();
					title=title==''?'New bookmark':title;
					configs.temp.addLink.title=title;
					addLink(el,json);
				}
			},{
				url:configs.temp.addLink.url,
				hl:configs.lang
			});
		}
		if(configs.temp.addLink.done){
			configs.temp.addLink.title=el.value;
			el.blur();
			return;
		}
		if(
			configs.temp.addLink.url&&
			configs.temp.addLink.title&&
			configs.temp.addLink.favicon
		){
			stopGo=false;
			jsl(el).attr({
				placeholder:getTranslations('transEnterName')||'Enter Name',
				tl:'placeholder:transEnterName'
			}).val(configs.temp.addLink.title).on('focus').removeAttribute('readonly').css('cursor','auto').select();
			jsl('.input-block-back').css('display','none');
			jsl(selector+' img').attr('src','/img/load.gif');
			jsl(selector+' img').css('display','none');
			jsl(selector).css('margin','0');
			configs.temp.addLink.done=true;
			el.addEventListener('blur',function(){
				configs.temp.addLink.title=el.value;
				var blockId=/input-block-wrap-(\d+)/.exec(jsl(el).parent().attr('data-num'))[1];
				json.blocks[getIndexBlock(blockId,json)]['links'].unshift({
					href:configs.temp.addLink.url,
					html:configs.temp.addLink.title,
					title:configs.temp.addLink.title,
					favicon_url:configs.temp.addLink.favicon,
				});
				notificationShow(getTranslations('transBookmarkSaved')||'Bookmark saved.','message');
				setTimeout(function(){stopGo=true;},100);
				updateData(json,{
					href:configs.temp.addLink.url,
					html:configs.temp.addLink.title,
					title:configs.temp.addLink.title,
					parentBlock:blockId
				},'addLink');
				delete configs.temp.addLink;
			},false);
			jsl.ajax({
				url:configs.domain+'/ss.json',
				type:'POST',
				headers:{
					'Content-Type':'application/x-www-form-urlencoded',
				}
			},{
				url:configs.temp.addLink.url
			});
		}
	}
	function appendCategory(ev){
		if(ev.keyCode==13){
			var json=JSON.parse(localStorage.dataBoard),
				max=-1,
				color=jsl('.color input[name="color"]:checked').attr('val'),
				objColor={
					def:'rgb(198,198,198)',
					red:'rgb(231,76,60)',
					yellow:'rgb(241,196,15)',
					green:'rgb(46,204,113)',
					bluew:'rgb(62,188,196)',
					blue:'rgb(52,152,219)',
					blueviolet:'rgb(155,89,182)',
					pink:'rgb(246,104,181)',
					pinkw:'rgb(255,174,201)',
					brown:'brown'
				};
			for(var i=0;i<json.blocks.length;i++)
				if(max<json.blocks[i]['id'])
					max=json.blocks[i]['id'];
			max=max==-1?0:++max;
			json.blocks.unshift({
				id:max,
				links:[],
				title:ev.target.value,
				parentColum:'0',
				color:objColor[color]||'rgb(128,128,128)'
			});
			jsl(configs.ids.popUp).css('display','none');
			notificationShow(getTranslations('transNewCategoryCreated')||'New category created.','message');
			updateData(json,{
				links:[],
				title:encode(ev.target.value),
				parentColum:'0',
				id:max
			},'addBlock');
		}
		ev.preventDefault();
		return false;
	}
	function extreme(arr){
		var resNum=arr.b[0];
		for(var j=0;j<arr.b.length;j++)
			if(jsl('.colum[data-num="colum-'+resNum+'"]').css('offsetHeight')>jsl('.colum[data-num="colum-'+arr.b[j]+'"]').css('offsetHeight'))
				resNum=arr.b[j];
		return resNum;
	}
	function notificationShow(ms,type){
		var color,h;
		switch(type){
			case 'warning':{color='rgb(245,160,0)';h=getTranslations('transWarning')||'Warning';}break;
			case 'error':{color='rgb(224,65,46)';h=getTranslations('transError')||'Error';}break;
			case 'message':{color='rgb(97,178,97)';h=getTranslations('transMessage')||'Message';}break;
		}
		if(translateStr(configs.html.notification)==undefined)
			return;
		var html=translateStr(configs.html.notification).replace('${h}',h).replace('${ms}',ms);
		jsl(configs.ids.windowMessage).html(html).css('background',color);
		jsl(configs.ids.windowMessage).attr('class','show').children('.closest').on('click',function(){
			jsl(configs.ids.windowMessage).attr('class','');
		});
		setTimeout(function(){
			jsl(configs.ids.windowMessage).attr('class','');
		},3e3);
	}
	function makeId(length){
		var result='',
			characters='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',
			charactersLength=characters.length;
		for(var i=0;i<length;i++)
			result+=characters.charAt(Math.floor(Math.random()*charactersLength));
		return result;
	}
	function updateData(json,update,method){
		update.timestamp=Date.now();
		json.timestamp=Date.now();
		json.data=saveHtml();
		if(json.hash==undefined)
			json.hash=makeId(255);
		json.dataVersionId=makeId(14);
		localStorage.dataBoard=JSON.stringify(json);
		configs.dataBoard=json;
		var ajax=jsl.ajax({
				url:configs.domain+'/ud.json',
				type:'POST',
				headers:{
					'Content-Type':'application/x-www-form-urlencoded',
				},
				onerror:function(e){
					if(typeof e=='string')
						notificationShow(e,'error');
					loader.stop();
					offLine();
				},
				4:function(res){
					if(res.status!=200){
						return ajax.onerror(getTranslations('transErrorConnection')||'Error connection!');
					}
					if(jsl.isJSON(res.response)==false)
						return ajax.onerror(getTranslations('transBadResponse')||'Bad response!');
					var serverJson=JSON.parse(res.response);
					if(serverJson.error){
						({
							401:function(){
								clearCash(clearSess);
							}
						})[serverJson.error]();
					}
				}
			},{
				data:JSON.stringify(json),
				update:update,
				method:method
			});
		renderDashboard(json);
		resizeDashboard(json);
		loader.stop();
	}
	function editBlockName(ev,name,json){
		var blockId=/input-name-block-(\d+)/.exec(jsl(ev.target).attr('data-num'))[1];
		json.blocks[getIndexBlock(blockId,json)].title=encode(name);
		notificationShow(getTranslations('transNameSaved')||'Name saved.','message');
		updateData(json,{
			blockId:blockId,
			newName:encode(name)
		},'editBlockName');
	}
	function mouseShowHandler(ev){
		ev=ev||window.event;
		if(ev.pageX==null&&ev.clientX!=null){
			var html=document.documentElement,
				body=document.body;
			ev.pageX=e.clientX+(html&&html.scrollLeft||body&&body.scrollLeft||0)-(html.clientLeft||0);
			ev.pageY=e.clientY+(html&&html.scrollTop||body&&body.scrollTop||0)-(html.clientTop||0);
		}
		window.pageX=ev.pageX;
		window.pageY=ev.pageY;
	}
	function drag(){
		var dropViewer=jsl('div').createElement({
				id:'drag-viewer'
			}),
			stops,
			dragObject={},
			dw={
				y:0,
				x:0
			},
			ew=function(ev){
				return{
					clientY:ev.clientY/*+jsl(configs.ids.blank).animate('scrollTop')-dw.y+dragObject.block.offsetHeight/2*/,
					clientX:ev.clientX+jsl(configs.ids.blank).animate('scrollLeft')-dw.x+dragObject.block.offsetWidth/2
				};
			},
			ewLink=function(ev){
				return{
					clientY:ev.clientY/*+jsl(configs.ids.blank).animate('scrollTop')-dw.y+dragObject.block.offsetHeight/2*/,
					clientX:ev.clientX+jsl(configs.ids.blank).animate('scrollLeft')-dw.x+dragObject.link.offsetWidth/2
				};
			},
			findDroppable=function(ev){
				ev=configs.dragPoint?ev:ew(ev);
				var elem=document.elementFromPoint(ev.clientX,ev.clientY),
					arr={};
				if(elem==dropViewer.a||elem==null)
					return;
				if(elem.closest('.colum'))arr.inColum=/colum-(\d+)/.exec(jsl(elem.closest('.colum')).attr('data-num'));
				if(elem.closest('.block')){
					arr.afterBlock=/block-(\d+)/.exec(jsl(elem.closest('.block')).attr('data-num'));
					arr.block=elem.closest('.block');
				}
				return arr;
			},
			findDroppableEmpty=function(ev){
				ev=configs.dragPoint?ev:ew(ev);
				var elem=document.elementFromPoint(ev.clientX,ev.clientY),
					arr={};
				if(elem==null)return;
				if(elem.closest('.colum'))arr.inColum=/colum-(\d+)/.exec(jsl(elem.closest('.colum')).attr('data-num'));
				if(elem.closest('.colum'))arr.inPosition=Array.prototype.slice.call(jsl(elem.closest('.colum')).children().a).indexOf(elem);
				if(elem.closest('.colum')){
					if(arr.inPosition==0)
						if(!(jsl(elem.closest('.colum')).children().length==1&&jsl(elem.closest('.colum')).children(0).a==dropViewer.a))
							arr.afterBlock=/block-(\d+)/.exec(jsl(elem.closest('.colum')).children().eq(arr.inPosition+1).attr('data-num'));
					if(arr.inPosition>0)
						arr.afterBlock=/block-(\d+)/.exec(jsl(elem.closest('.colum')).children().eq(arr.inPosition-1).attr('data-num'));
				}
				return arr;
			},
			findDroppableLink=function(ev,nameEvent){
				ev=configs.dragPoint?ev:ewLink(ev);
				var elem=document.elementFromPoint(ev.clientX,ev.clientY),
					arr={};
				arr.test=elem;
				if(nameEvent=='move')
					if(elem==dropViewer.a||elem==null)
						return;
				if(elem.closest('.block')){
					arr.inBlock=/block-(\d+)/.exec(jsl(elem.closest('.block')).attr('data-num'));
					if(elem.closest('.link'))
						arr.link=/link-(\d+)/.exec(jsl(elem.closest('.link')).attr('data-num'));
					arr.block=elem.closest('.block');
					arr.linkE=elem.closest('.link');
				}
				return arr;
			},
			down=function(ev){
				if(ev.which!=1||stopGo==false)
					return;
				if(ev.target==dropViewer.a)
					return;
				if(!localStorage.dataBoard)
					return;
				var json=JSON.parse(localStorage.dataBoard);
				if(jsl(configs.ids.body).css('offsetWidth')<Number(json.countColum)*Number(json.columMinWid)){
					return;
				}
				var link=ev.target.closest('.link'),
					block=ev.target.closest('.name'),
					blockL=ev.target.closest('.block'),
					colum=ev.target.closest('.colum');
				if(!link&&!block)
					return;
				if(link){
					dw.y=window.pageY-jsl(link).getCoordinates().top;
					dw.x=window.pageX-jsl(link).getCoordinates().left;
					dragObject.link=link;
					dragObject.numBlock=/block-(\d+)/.exec(blockL.getAttribute('data-num'));
					dragObject.num=/link-(\d+)/.exec(link.getAttribute('data-num'));
					dragObject.link=ev.target.closest('.link');
					dragObject.downX=ev.pageX;
					dragObject.downY=ev.pageY;
					dragObject.moveStart=false;
					dropViewer.css({
						height:'26px'
					});
					dragObject.link.onclick=function(){
						return false;
					};
					document.onmousemove=moveLink;
					document.onmouseup=upLink;
					window.onblur=function(){
						var json=JSON.parse(localStorage.dataBoard);
						json.data=saveHtml();
						localStorage.dataBoard=JSON.stringify(json);
						configs.dataBoard=json;
						renderDashboard(json);
						resizeDashboard(json);
						dragObject={};
						document.onmousemove=null;
						document.onmouseup=null;
						window.onblur=null;
						clearInterval(stops);
						jsl('.delete').css('display','none');
						return false;
					};
				}
				if(block){
					dw.y=ev.offsetY;
					dw.x=ev.offsetX;
					dragObject.numColum=/colum-(\d+)/.exec(colum.getAttribute('data-num'));
					dragObject.num=/name-block-(\d+)/.exec(block.getAttribute('data-num'));
					dragObject.block=ev.target.closest('.block');
					dragObject.downX=ev.pageX;
					dragObject.downY=ev.pageY;
					dragObject.moveStart=false;
					document.onmousemove=moveBlock;
					document.onmouseup=upBlock;
					dropViewer.css({
						height:'44px'
					});
					window.onblur=function(){
						var json=JSON.parse(localStorage.dataBoard);
						json.data=saveHtml();
						localStorage.dataBoard=JSON.stringify(json);
						configs.dataBoard=json;
						renderDashboard(json);
						resizeDashboard(json);
						dragObject={};
						document.onmousemove=null;
						document.onmouseup=null;
						window.onblur=null;
						clearInterval(stops);
						jsl('.delete').css('display','none');
						return false;
					};
					ev.preventDefault();
					return false;
				}
			},
			moveLink=function(ev){
				var indertPrevLink=function(inBlock,dropElem,position){
						jsl('.block[data-num="block-'+inBlock+'"] .link-block').append(dropViewer);
						var arr=jsl('.block[data-num="block-'+inBlock+'"] .link-block .wrap-link-span');
						if(arr.a==null){
							jsl('.block[data-num="block-'+inBlock+'"] .link-block').append(dropElem);
						}else{
							if(position==0&&arr.length==1){
								jsl('.block[data-num="block-'+inBlock+'"] .link-block').insertBefore(dropElem,arr.a);
							}else{
								jsl('.block[data-num="block-'+inBlock+'"] .link-block').insertBefore(dropElem,arr.a[position]);
							}
						}
					};
				if((ev.pageY-10<0||ev.pageY+10>window.innerHeight)&&stops==undefined){
					if(ev.pageY-10<0)
						stops=setInterval(function(){
							if(jsl(configs.ids.blank).css('offsetHeight')<jsl(configs.ids.holder).css('offsetHeight'))
								jsl(configs.ids.blank).scrollTo(0,jsl(configs.ids.blank).animate('scrollTop')-10);
						},35);
					if(ev.pageY+10>window.innerHeight)
						stops=setInterval(function(){
							if(jsl(configs.ids.blank).css('offsetHeight')<jsl(configs.ids.holder).css('offsetHeight'))
								jsl(configs.ids.blank).scrollTo(0,jsl(configs.ids.blank).animate('scrollTop')+10);
						},35);
				}
				if((ev.pageY-10>0&&ev.pageY+10<window.innerHeight)&&stops!=undefined){
					clearInterval(stops);
					stops=undefined;
				}
				if(ev.target==dropViewer.a){
					ev.preventDefault();
					return false;
				}
				if(Math.abs(ev.clientX-dragObject.downX)<10&&Math.abs(ev.clientY-dragObject.downY)<10){
					ev.preventDefault();
					return false;
				}
				jsl(dragObject.link).css({
					position:'absolute',
					width:jsl(dragObject.link).css('offsetWidth')-2+'px',
					left:'-9999px',
					'z-index':-10
				});
				jsl(configs.ids.body+' .block .wrap-block').css('height','');
				if(jsl('#drag-viewer').length==0)
					indertPrevLink(dragObject.numBlock[1],dropViewer.a,Number(dragObject.num[1])+1);
				var dragResult=findDroppableLink(ev,'move');
				if(document.elementFromPoint(ev.clientX,ev.clientY)==jsl('.delete').a||document.elementFromPoint(ev.clientX,ev.clientY)==jsl(configs.ids.topNav+' .delete img').a){
					dropViewer.css('display','none');
					dragObject.delete=true;
					jsl(configs.ids.topNav+' .delete').css({
						background:'rgb(230,0,0)',
						color:'rgb(255,255,255)'
					});
					jsl(configs.ids.topNav+' .delete img').css({
						filter:'brightness(1)'
					});
				}else{
					dropViewer.css('display','block');
					dragObject.delete=false;
					jsl(configs.ids.topNav+' .delete').css({
						background:'',
						color:''
					}).css('display','block');
					jsl(configs.ids.topNav+' .delete img').css({
						filter:'brightness(.8)'
					});
					jsl(configs.ids.body+' .block .wrap-block').css('height','100%');
					jsl('.title-block .open-all').css('display','none');
					jsl('.title-block .pencil').css('display','none');
					jsl('.title-block .plus').css('display','none');
				}
				jsl(dragObject.link).css({
					position:'fixed',
					top:(ev.clientY-dw.y-1+jsl(configs.ids.blank).animate('scrollTop'))+'px',
					left:(ev.clientX-dw.x-1)+'px',
					width:jsl(dragObject.link).css('offsetWidth')-46+'px',
					height:jsl(dragObject.link).css('offsetHeight')-14+'px',
					'z-index':1,
					'padding-left':'16px',
					background:'transparent',
					border:'1px solid rgba(128,128,128,.5)',
					'backdrop-filter':'blur(5px)',
				});
				jsl(configs.ids.body+' .block .wrap-block').css('height','100%');
				if(typeof dragObject.link=='object'&&dragObject.moveStart==false&&typeof dragObject.num=='object'&&typeof dragObject.numBlock=='object'){
					dragObject.position=Number(dragObject.num[1])+1;
					indertPrevLink(dragObject.numBlock[1],dropViewer.a,Number(dragObject.num[1])+1);
				}
				if(Math.abs(ev.clientX-dragObject.downX)<10&&Math.abs(ev.clientY-dragObject.downY)<10){
					ev.preventDefault();
					return false;
				}else
					dragObject.moveStart=true;
				if(dragResult==undefined||dragResult.inBlock==undefined||dragResult.block==undefined){
					ev.preventDefault();
					return false;
				}
				var indexInBlock=dragResult.inBlock[1],
					indexAfterBlock,
					snf=0,
					draggedBlock=getIndexBlock(dragObject.num[1]),
					json=JSON.parse(localStorage.dataBoard);
				if(dragObject.moveStart){
					if(dragResult.link==undefined&&dragResult.block!=undefined&&dragResult.inBlock!=undefined){
						if(dragResult.test.className=='borrom-border')
							dragObject.position=json.blocks[getIndexBlock(indexInBlock)].links.length;
						else
							dragObject.position=0;
						indertPrevLink(dragResult.inBlock[1],dropViewer.a,dragObject.position);
					}else{
						if(dragResult!=undefined&&dragResult.inBlock!=undefined){
							var indexInBlock=dragResult.inBlock[1],
								splicedElem;
							if(dragResult.link!=undefined)
								if(ev.y-jsl(dragResult.linkE).getCoordinates().top<jsl(dragResult.linkE).css('offsetHeight')/2)
									snf=1;
							if(snf==0){
								dragObject.position=Number(dragResult.link[1])+1;
								indertPrevLink(dragResult.inBlock[1],dropViewer.a,Number(dragResult.link[1])+1);
							}
							if(snf==1){
								dragObject.position=Number(dragResult.link[1]);
								indertPrevLink(dragResult.inBlock[1],dropViewer.a,Number(dragResult.link[1]));
							}
						}
					}
				}
				ev.preventDefault();
				return false;
			},
			upLink=function(ev){
				if(dragObject.moveStart==false){
					clearInterval(stops);
					document.onmousemove=null;
					document.onmouseup=null;
					window.onblur=null;
					toGo(dragObject.link.href,ev);
					ev.preventDefault();
					return false;
				}
				jsl(dragObject.link).css({
					top:'',
					left:'',
					width:'',
					'z-index':1,
					border:'none',
					position:'relative',
					background:'transparent'
				});
				var json=JSON.parse(localStorage.dataBoard),
					dl=null,
					dragResult=findDroppableLink(ev,'up'),
					indexBlock=getIndexBlock(dragObject.numBlock[1],json),
					indexLink=getIndexLink(indexBlock,dragObject.num[1],json);
				if(dragResult!=undefined&&dragResult.inBlock!=undefined){
					if(dragResult.block&&dragObject.moveStart){
						var inBlock=getIndexBlock(dragResult.inBlock[1]),
							sp=json.blocks[indexBlock].links.splice(indexLink,1);
						if(indexBlock==inBlock)
							if(indexLink<dragObject.position)
								dragObject.position=dragObject.position-1;
						json.blocks[inBlock].links.splice(dragObject.position,0,sp[0]);
					}
				}
				if(dragObject.delete||document.elementFromPoint(ev.clientX,ev.clientY)==jsl('.delete').a||document.elementFromPoint(ev.clientX,ev.clientY)==jsl(configs.ids.topNav+' .delete img').a)
					dl=json.blocks[indexBlock].links.splice(indexLink,1);
				setTimeout(function(){dragObject.link.onclick=null;},100);
				jsl('.delete').css('display','none');
				json.data=saveHtml();
				localStorage.dataBoard=JSON.stringify(json);
				configs.dataBoard=json;
				renderDashboard(json);
				resizeDashboard(json);
				clearInterval(stops);
				document.onmousemove=null;
				document.onmouseup=null;
				window.onblur=null;
				if(dl!=null){
					notificationShow(getTranslations('transLinkRemoved')||'Link removed.','message');
					updateData(json,{
						block:indexBlock,
						link:indexLink
					},'deleteLink');
				}else{
					if(dragResult!=undefined&&dragResult.inBlock!=undefined){
						if(dragObject.moveStart==true){
							notificationShow(getTranslations('transMovingSaved')||'Moving saved.','message');
							updateData(json,{
								fromBlock:indexBlock,
								inBlock:inBlock
							},'dragLink');
						}
					}
				}
				return false;
			},
			moveBlock=function(ev){
				jsl(configs.ids.body).addClass('drag');
				var countBlocks=function(indexInColum){
						var countBlocks=0;
						for(var i=0;i<json.blocks.length;i++){
							if(json.blocks[i].parentColum==indexInColum){
								++countBlocks;
							}
						}
						return countBlocks;
					},
					countBlocksIn=function(indexInColum,indexAfterBlock){
						var countBlocks=0;
						for(var i=0;i<json.blocks.length;i++){
							if(json.blocks[i].parentColum==indexInColum){
								if(i==Number(indexAfterBlock))
									return countBlocks;
								++countBlocks;
							}
						}
						return countBlocks;
					},
					indertPrev=function(inColum,dropElem,position){
						jsl('.colum[data-num="colum-'+inColum+'"]').append(dropViewer);
						var arr=jsl('.colum[data-num="colum-'+inColum+'"] .block');
						if(arr.a.length==undefined&&arr.length==1){
							if(position==0){
								jsl('.colum[data-num="colum-'+inColum+'"]').insertBefore(dropElem,arr.a);
							}
						}else{
							for(var i=0;i<arr.a.length;i++){
								if(i==position){
									if(i==0){
										jsl('.colum[data-num="colum-'+inColum+'"]').insertBefore(dropElem,arr.a[i]);
									}else{
										jsl('.colum[data-num="colum-'+inColum+'"]').insertBefore(dropElem,arr.a[i]);
									}
								}
							}
						}
					};
				if((ev.pageY-10<0||ev.pageY+10>window.innerHeight)&&stops==undefined){
					if(ev.pageY-10<0)
						stops=setInterval(function(){
							if(jsl(configs.ids.blank).css('offsetHeight')<jsl(configs.ids.holder).css('offsetHeight'))
								jsl(configs.ids.blank).scrollTo(0,jsl(configs.ids.blank).animate('scrollTop')-10);
						},35);
					if(ev.pageY+10>window.innerHeight)
						stops=setInterval(function(){
							if(jsl(configs.ids.blank).css('offsetHeight')<jsl(configs.ids.holder).css('offsetHeight'))
								jsl(configs.ids.blank).scrollTo(0,jsl(configs.ids.blank).animate('scrollTop')+10);
						},35);
				}
				if(dragObject.block!=undefined){
					if(Math.abs(ev.clientX-dragObject.downX)<10&&Math.abs(ev.clientY-dragObject.downY)<10&&dragObject.moveStart==false){
						ev.preventDefault();
						return false;
					}else
						dragObject.moveStart=true;
				}
				if((ev.pageY-10>0&&ev.pageY+10<window.innerHeight)&&stops!=undefined){
					clearInterval(stops);
					stops=undefined;
				}
				if(ev.target==dropViewer.a){
					ev.preventDefault();
					return false;
				}
				jsl(dragObject.block).css({
					position:'absolute',
					width:jsl(dragObject.block).css('offsetWidth')-2+'px',
					left:'-9999px',
					'z-index':-10
				});
				if(document.elementFromPoint(ev.clientX,ev.clientY)==jsl('.delete').a||document.elementFromPoint(ev.clientX,ev.clientY)==jsl(configs.ids.topNav+' .delete img').a){
					dropViewer.css('display','none');
					dragObject.delete=true;
					jsl(configs.ids.topNav+' .delete').css({
						background:'rgb(230,0,0)',
						color:'rgb(255,255,255)'
					});
					jsl(configs.ids.topNav+' .delete img').css({
						filter:'brightness(1)'
					});
				}else{
					dropViewer.css('display','block');
					dragObject.delete=false;
					jsl(configs.ids.topNav+' .delete').css({
						background:'',
						color:''
					}).css('display','block');
					jsl(configs.ids.topNav+' .delete img').css({
						filter:'brightness(.8)'
					});
					jsl(configs.ids.body+' .block .wrap-block').css('height','100%');
					jsl('.title-block .open-all').css('display','none');
					jsl('.title-block .pencil').css('display','none');
					jsl('.title-block .plus').css('display','none');
				}
				var dragResult=findDroppable(ev);
				jsl(dragObject.block).css({
					position:'absolute',
					top:(ev.clientY+jsl(configs.ids.blank).animate('scrollTop')-dw.y-1)+'px',
					left:(ev.clientX+jsl('body').animate('scrollLeft')-dw.x)+'px',
					width:jsl(dragObject.block).css('offsetWidth')-2+'px',
					'z-index':1,
					'backdrop-filter':'blur(5px)',
					background:'transparent',
					border:'1px solid rgba(128,128,128,.5)'
				});
				if(dragResult==undefined||dragResult.inColum==undefined||dragObject.num==undefined){
					ev.preventDefault();
					return false;
				}
				var indexInColum=dragResult.inColum[1],
					indexAfterBlock,
					snf=0,
					draggedBlock=getIndexBlock(dragObject.num[1]),
					json=JSON.parse(localStorage.dataBoard);
				if(dragResult!=undefined&&dragResult.inColum!=undefined){
					var indexInColum=dragResult.inColum[1],
						indexAfterBlock,
						splicedElem,
						snf=0,
						draggedBlock=getIndexBlock(dragObject.num[1]);
					if(dragResult.afterBlock==undefined){
						var adasd=0;
						for(var i=json.blocks.length;i--;){
							if(json.blocks[i].parentColum==indexInColum){
								adasd=i;
								break;
							}
						}
						indexAfterBlock=adasd>0?adasd:0;
						++indexAfterBlock;
					}else
						indexAfterBlock=getIndexBlock(dragResult.afterBlock[1]);
					if(dragResult.afterBlock!=undefined)
						if(ev.y-jsl(dragResult.block).getCoordinates().top<jsl(dragResult.block).css('offsetHeight')/2)
							snf=1;
					if(dragResult.afterBlock==undefined){
						if(dragObject.numColum[1]==indexInColum)
							jsl('.colum[data-num="colum-'+indexInColum+'"]').append(dropViewer);
						else
							jsl('.colum[data-num="colum-'+indexInColum+'"]').append(dropViewer);
					}else{
						if(snf==0){
							if(Number(draggedBlock)>Number(indexAfterBlock))
								indertPrev(indexInColum,dropViewer.a,countBlocksIn(indexInColum,indexAfterBlock)+1);
							if(Number(draggedBlock)<Number(indexAfterBlock))
								indertPrev(indexInColum,dropViewer.a,countBlocksIn(indexInColum,indexAfterBlock)+1);
						}
						if(snf==1){
							if(Number(draggedBlock)>Number(indexAfterBlock))
								indertPrev(indexInColum,dropViewer.a,countBlocksIn(indexInColum,indexAfterBlock));
							if(Number(draggedBlock)<Number(indexAfterBlock))
								indertPrev(indexInColum,dropViewer.a,countBlocksIn(indexInColum,indexAfterBlock));
						}
					}
				}
				ev.preventDefault();
				return false;
			},
			upBlock=function(ev){
				jsl(configs.ids.body).removeClass('drag');
				jsl(dragObject.block).css({
					top:'',
					left:'',
					width:'',
					'z-index':1,
					border:'none',
					position:'relative',
					background:'transparent'
				});
				var json=JSON.parse(localStorage.dataBoard),
					dragResult=findDroppable(ev),
					dl=null;
				if(dragResult!=undefined&&dragResult.inColum!=undefined){
					var indexInColum=dragResult.inColum[1],
						indexAfterBlock,
						splicedElem,
						snf=0,
						draggedBlock=getIndexBlock(dragObject.num[1]);
					if(dragResult.afterBlock==undefined){
						var adasd=0;
						for(var i=json.blocks.length;i--;){
							if(json.blocks[i].parentColum==indexInColum){
								adasd=i;
								break;
							}
						}
						indexAfterBlock=adasd>0?adasd:0;
						++indexAfterBlock;
					}else{
						indexAfterBlock=getIndexBlock(dragResult.afterBlock[1]);
					}
					if(dragResult.afterBlock!=undefined){
						if(ev.y-jsl(dragResult.block).getCoordinates().top<jsl(dragResult.block).css('offsetHeight')/2)
							snf=1;
					}
					json.blocks[draggedBlock].parentColum=indexInColum;
					if(Number(draggedBlock)!=Number(indexAfterBlock))
						splicedElem=json.blocks.splice(Number(draggedBlock),1);
					if(snf==0){
						if(Number(draggedBlock)>Number(indexAfterBlock))
							json.blocks.splice(Number(indexAfterBlock)+1,0,splicedElem[0]);
						if(Number(draggedBlock)<Number(indexAfterBlock))
							json.blocks.splice(Number(indexAfterBlock),0,splicedElem[0]);
					}
					if(snf==1){
						if(Number(draggedBlock)>Number(indexAfterBlock))
							json.blocks.splice(Number(indexAfterBlock),0,splicedElem[0]);
						if(Number(draggedBlock)<Number(indexAfterBlock))
							json.blocks.splice(Number(indexAfterBlock),0,splicedElem[0]);
					}
				}else{
					dragResult=findDroppableEmpty(ev)||{};
					if(dragResult.inColum!=undefined){
						var indexInColum=dragResult.inColum[1],
							indexAfterBlock,
							splicedElem,
							snf=0,
							draggedBlock=getIndexBlock(dragObject.num[1]);
						if(dragResult.afterBlock==undefined){
							var adasd=0;
							for(var i=json.blocks.length;i--;){
								if(json.blocks[i].parentColum==indexInColum){
									adasd=i;
									break;
								}
							}
							indexAfterBlock=adasd>0?adasd:0;
							++indexAfterBlock;
						}else
							indexAfterBlock=getIndexBlock(dragResult.afterBlock[1]);
						if(dragResult.afterBlock!=undefined)
							if(dragResult.inPosition==0)
								snf=1;
						json.blocks[draggedBlock].parentColum=indexInColum;
						if(Number(draggedBlock)!=Number(indexAfterBlock))
							splicedElem=json.blocks.splice(Number(draggedBlock),1);
						if(snf==0){
							if(Number(draggedBlock)>Number(indexAfterBlock))
								json.blocks.splice(Number(indexAfterBlock)+1,0,splicedElem[0]);
							if(Number(draggedBlock)<Number(indexAfterBlock))
								json.blocks.splice(Number(indexAfterBlock),0,splicedElem[0]);
						}
						if(snf==1){
							if(Number(draggedBlock)>Number(indexAfterBlock))
								json.blocks.splice(Number(indexAfterBlock),0,splicedElem[0]);
							if(Number(draggedBlock)<Number(indexAfterBlock))
								json.blocks.splice(Number(indexAfterBlock)-1,0,splicedElem[0]);
						}
					}
				}
				if(dragObject.delete||document.elementFromPoint(ev.clientX,ev.clientY)==jsl('.delete').a||document.elementFromPoint(ev.clientX,ev.clientY)==jsl(configs.ids.topNav+' .delete img').a)
					dl=json.blocks.splice(getIndexBlock(dragObject.num[1],json),1);
				jsl('.delete').css('display','none');
				json.data=saveHtml();
				localStorage.dataBoard=JSON.stringify(json);
				configs.dataBoard=json;
				renderDashboard(json);
				resizeDashboard(json);
				clearInterval(stops);
				document.onmousemove=null;
				document.onmouseup=null;
				window.onblur=null;
				if(json.blocks.length==0){
					jsl(configs.ids.topNav).html(translateStr(configs.html.topNavLog));
					jsl(configs.ids.body).html(translateStr(configs.html.mainLog));
				}
				if(dl!=null){
					notificationShow(getTranslations('transCategoryRemoved')||'Category removed.','message');
					updateData(json,{
						block:dl[0].id,
						parentColum:dl[0].parentColum
					},'deleteBlock');
				}else{
					if(dragResult!=undefined&&dragResult.inColum!=undefined){
						if(dragObject.moveStart==true){
							notificationShow(getTranslations('transMovingSaved')||'Moving saved.','message');
							updateData(json,{
								fromColumn:indexInColum,
								block:draggedBlock,
								inColum:indexInColum,
								after:indexAfterBlock
							},'dragBlock');
						}
					}
				}
				return false;
			};
		document.onmousedown=down;
	}
	function renderDashboard(json){
		if(json==undefined)
			json=JSON.parse(localStorage.dataBoard);
		var countColum=Number(json.countColum),
			body=jsl(configs.ids.body),
			parrentElement=jsl(body).parent(),
			scrollTop=jsl(configs.ids.blank).animate('scrollTop');
		if(json.borders!=undefined){
			jsl(configs.ids.body).attr('class',json.borders);
		}
		if(json.fontSize!=undefined){
			jsl(configs.ids.holder).attr('class',json.fontSize);
		}
		if(json.theme!=undefined){
			if(json.theme){
				jsl('body').attr('id','dark');
				jsl(configs.ids.blank).css('background','');
				jsl('link[rel="shortcut icon"]').attr('href',translateStr(configs.html.faviconDark));
				jsl(configs.ids.topNav+' .top .left .logo-block .logo').attr('src',translateStr(configs.html.logoDark));
				jsl(configs.ids.topNav+' .top .left .cancel').attr('src',translateStr(configs.html.closeIconDark));
				jsl(configs.ids.topNav+' .top .right .details .summary.material-icons.gear>img').attr({
					src:translateStr(configs.html.menuIconDark)
				});
				jsl('meta[name="theme-color"]').attr('content','#202020');
				jsl('meta[name="msapplication-TileColor"]').attr('content','#202020');
				jsl('meta[name="msapplication-navbutton-color"]').attr('content','#202020');
				jsl('meta[name="apple-mobile-web-app-status-bar-style"]').attr('content','#202020');
			}else{
				jsl('body').attr('id','light');
				jsl(configs.ids.blank).css('background','');
				jsl('link[rel="shortcut icon"]').attr('href',translateStr(configs.html.favicon));
				jsl(configs.ids.topNav+' .top .left .logo-block .logo').attr('src',translateStr(configs.html.logo));
				jsl(configs.ids.topNav+' .top .left .cancel').attr('src',translateStr(configs.html.closeIcon));
				jsl(configs.ids.topNav+' .top .right .details .summary.material-icons.gear>img').attr({
					src:translateStr(configs.html.menuIcon)
				});
				jsl('meta[name="theme-color"]').attr('content','#ffffff');
				jsl('meta[name="msapplication-TileColor"]').attr('content','#ffffff');
				jsl('meta[name="msapplication-navbutton-color"]').attr('content','#ffffff');
				jsl('meta[name="apple-mobile-web-app-status-bar-style"]').attr('content','#ffffff');
			}
		}
		if(json.screenshot!=undefined){
			if(json.screenshot){
				jsl('.link-screenshot').css('display','block');
			}else{
				jsl('.link-screenshot').css('display','none');
			}
		}
		if(Number(json.countColum)>0){
			jsl(configs.ids.topNav).children('.menu input.colum-min-width').val(Number(json.columMinWid))/*.attr('max',String(parrentElement.css('offsetWidth')/Number(json.countColum)))*/;
			jsl(configs.ids.topNav).children('.menu select.count-colum').val(Number(json.countColum)).attr('max',String(Math.trunc(parrentElement.css('offsetWidth')/Number(json.columMinWid))));
			jsl(configs.ids.topNav).children('.menu input.change-flow').prop('checked',json.dragPoint);
			jsl(configs.ids.topNav).children('.menu input.borders[value="'+json.borders+'"]').eq(0).prop('checked',true);
			jsl(configs.ids.topNav).children('.menu input.font-size[value="'+json.fontSize+'"]').eq(0).prop('checked',true);
			jsl(configs.ids.topNav).children('.menu input.theme').prop('checked',json.theme);
			jsl(configs.ids.topNav).children('.menu input.screenshot').prop('checked',json.screenshot);
			jsl(configs.ids.topNav).children('.menu input.open-new-tab').prop('checked',json.openNewTab);
			jsl(configs.ids.topNav).children('.menu input.show-tooltip').prop('checked',json.showTooltip);
			jsl(configs.ids.topNav).children('.menu select.searchservice').prop('value',json.searchService);
			if(Number(json.countColum)>0&&json['blocks'].length>0){
				body.html('');
				for(var i=0;i<Number(json.countColum);i++){
					var colum=jsl('div').createElement({
						class:'colum',
						'data-num':'colum-'+i
					});
					body.append(colum);
				}
			}
		}
		if(json['blocks'].length>0){
			for(var j=0;j<json['blocks'].length;j++){
				var block=jsl('div').createElement({
						class:'block',
						'data-num':'block-'+json['blocks'][j]['id']||j
					}),
					wrapBlock=jsl('div').createElement({
						class:'wrap-block'
					}),
					titleBlock=jsl('div').createElement({
						class:'title-block',
						'data-num':'title-block-'+json['blocks'][j]['id']||j,
						style:{
							'border-color':json['blocks'][j]['color']||''
						}
					}),
					nameBlock=jsl('div').createElement({
						class:'name',
						'data-num':'name-block-'+json['blocks'][j]['id']||j
					}).html(json['blocks'][j]['title']||getTranslations('transTitle')||'Title'),
					inputBlock=jsl('div').createElement({
						class:'input-block',
						'data-num':'input-block-'+json['blocks'][j]['id']||j
					}),
					inputName=jsl('input').createElement({
						class:'input-name',
						'data-num':'input-name-block-'+json['blocks'][j]['id']||j,
						placeholder:getTranslations('transEnterName')||'Enter Name',
						style:{
							display:'none'
						},
						name:'input-name',
						tl:'placeholder:transEnterName'
					}),
					editBlock=jsl('div').createElement({
						class:'pencil',
						title:getTranslations('transEditNameCategory')||'Edit name category',
						'data-num':'edit-block-'+json['blocks'][j]['id']||j,
						tl:'title:transEditNameCategory'
					}).prop({
						inb:nameBlock,
						ini:inputName
					}).html(jsl('img').createElement({
						height:'16',
						width:'16',
						src:json.theme?translateStr(configs.html.editNameDark):translateStr(configs.html.editName),
						title:getTranslations('transEditNameCategory')||'Edit name category',
						alt:getTranslations('transEditNameCategory')||'Edit name category',
						'data-num':'edit-block-'+json['blocks'][j]['id']||j,
						tl:'title:transEditNameCategory'
					}).a),
					openAll=jsl('div').createElement({
						class:'open-all',
						title:getTranslations('transOpenAllLink')||'Open all link',
						'data-num':'open-all-'+json['blocks'][j]['id']||j
					}).html(jsl('img').createElement({
						src:json.theme?translateStr(configs.html.openAllDark):translateStr(configs.html.openAll),
						title:getTranslations('transOpenAllLink')||'Open all link',
						alt:getTranslations('transOpenAllLink')||'Open all link',
						tl:'title:transOpenAllLink',
						'data-num':'open-all-'+json['blocks'][j]['id']||j,
						height:'16',
						width:'16'
					}).a),
					inputBlockBack=jsl('div').createElement({
						class:'input-block-back',
						'data-num':'input-block-back-'+json['blocks'][j]['id']||j
					}),
					inputBlockWrap=jsl('div').createElement({
						class:'input-block-wrap',
						'data-num':'input-block-wrap-'+json['blocks'][j]['id']||j
					}),
					clAdd=jsl('img').createElement({
						class:'close',
						title:getTranslations('transCancel')||'Cancel',
						alt:getTranslations('transCancel')||'Cancel',
						src:json.theme?translateStr(configs.html.closeIconDark):translateStr(configs.html.closeIcon),
						tl:'title:transCancel',
						'data-num':'close-'+json['blocks'][j]['id']||j,
						height:'16',
						width:'16'
					}).prop({
						inb:inputBlock,
						ini:input
					}).on('mousedown',function(ev){
						ev.preventDefault();
						return false;
					}),
					input=jsl('input').createElement({
						class:'input',
						name:'link-url',
						'data-num':'input',
						tl:'placeholder:transEnterUrl',
						placeholder:getTranslations('transEnterUrl')||'Enter Url',
						tl:'placeholder:transEnterUrl',
					}).prop({
						inb:inputBlockBack,
						ini:inputBlock,
						cli:clAdd
					}),
					plusBlock=jsl('div').createElement({
						class:'plus',
						title:getTranslations('transAddLink')||'Add link',
						'data-num':'plus-block-'+json['blocks'][j]['id']||j,
						tl:'title:transAddLink'
					}).prop({
						inb:inputBlock,
						ini:input
					}).html(jsl('img').createElement({
						src:json.theme?translateStr(configs.html.addLinkDark):translateStr(configs.html.addLink),
						title:getTranslations('transAddLink')||'Add link',
						alt:getTranslations('transAddLink')||'Add link',
						'data-num':'plus-block-'+json['blocks'][j]['id']||j,
						tl:'title:transAddLink',
						height:'16',
						width:'16'
					}).a),
					settingBlock=jsl('div').createElement({
						class:'settings-block',
						'data-num':'settings-block-'+json['blocks'][j]['id']||j
					}),
					linkBlock=jsl('div').createElement({
						class:'link-block',
						'data-num':'link-block-'+json['blocks'][j]['id']||j
					}),
					bottomBorder=jsl('div').createElement({
						class:'borrom-border',
						'data-num':'borrom-border-'+json['blocks'][j]['id']||j
					}),
					columNumAppend=json.blocks[j]['parentColum']<Number(json.countColum)?json.blocks[j]['parentColum']:countColum<=0?0:--countColum;
				clAdd.a.addEventListener('click',function(ev){
					loader.stop();
					jsl(this.inb).css('display','none');
					setTimeout(function(){stopGo=true;},100);
				});
				editBlock.a.addEventListener('click',function(ev){
					var blockId=/edit-block-(\d+)/.exec(jsl(ev.target).attr('data-num'))[1],
						val=decode(json.blocks[getIndexBlock(blockId,json)].title);
					loader.start(blockId);
					jsl(this.ini).css('display','block').on('focus').val(val).attr('default',val).select();
					jsl(this.inb).css('display','none');
					stopGo=false;
				},false);
				plusBlock.a.addEventListener('click',function(ev){
					jsl('.input-block').css('display','none');
					loader.start(/input-block-(\d+)/.exec(this.inb.a.attributes['data-num'].value)[1]);
					jsl(this.inb).css('display','block');
					jsl(this.ini).parent().css('margin','0 30px 0 0');
					jsl(this.inb).childrenAll('.close').eq(0).css('display','block');
					jsl(this.ini).on('focus');
					stopGo=false;
				},false);
				openAll.a.addEventListener('click',function(ev){
					var blockId=/open-all-(\d+)/.exec(jsl(ev.target).attr('data-num'))[1];
					for(var i=0;i<json.blocks[getIndexBlock(blockId,json)].links.length;i++)
						window.open(json.blocks[getIndexBlock(blockId,json)].links[i].href);
				},false);
				input.a.addEventListener('keyup',function(ev){
					if(ev.keyCode==13&&ev.target.value!=''){
						var json=JSON.parse(localStorage.dataBoard);
						addLink(ev.target,json);
					}
				},false);
				input.a.addEventListener('keydown',function(ev){
					if(ev.keyCode!=27)
						return;
					loader.stop();
					jsl(this.ini).css('display','none');
					setTimeout(function(){stopGo=true;},100);
				},false);
				inputName.a.addEventListener('keyup',function(ev){
					if(ev.keyCode==13){
						if(ev.target.value==jsl(ev.target).attr('default')){
							var blockId=/input-name-block-(\d+)/.exec(jsl(ev.target).attr('data-num'))[1];
							jsl('.input-name').css('display','none');
							jsl('.name').css('display','block');
							loader.stop();
							setTimeout(function(){stopGo=true;},100);
						}else{
							var json=JSON.parse(localStorage.dataBoard);
							editBlockName(ev,ev.target.value,json);
							setTimeout(function(){stopGo=true;},100);
						}
					}
				},false);
				inputName.a.addEventListener('keydown',function(ev){
					if(ev.keyCode==27){
						var blockId=/input-name-block-(\d+)/.exec(jsl(ev.target).attr('data-num'))[1];
						jsl('.input-name').css('display','none');
						jsl('.name').css('display','block');
						loader.stop();
						setTimeout(function(){stopGo=true;},100);
					}
				},false);
				inputName.a.addEventListener('blur',function(ev){
					if(stopGo)
						return;
					if(ev.target.value==jsl(ev.target).attr('default')){
						var blockId=/input-name-block-(\d+)/.exec(jsl(ev.target).attr('data-num'))[1];
						jsl('.input-name').css('display','none');
						jsl('.name').css('display','block');
						loader.stop();
						setTimeout(function(){stopGo=true;},100);
					}else{
						var json=JSON.parse(localStorage.dataBoard);
						editBlockName(ev,ev.target.value,json);
						setTimeout(function(){stopGo=true;},100);
					}
				},false);
				if(json['blocks'][j]['links'].length>0){
					for(var k=0;k<json['blocks'][j]['links'].length;k++){
						var linkA=jsl('a').createElement({
								class:'link',
								'data-num':'link-'+k,
								rel:'nofollow',
								href:json['blocks'][j]['links'][k]['href'],
								title:decode(json['blocks'][j]['links'][k]['title']||getTranslations('transEditThisLink')||'New bookmark')+' | '+json['blocks'][j]['links'][k]['href']
							}).on('mouseenter',function(){
								var json=json||JSON.parse(localStorage.dataBoard);
								json.showTooltip==true&&jsl(configs.ids.windowTooltip).html(this.attr('title')).addClass('show');
							}).on('mouseleave',function(){
								jsl(configs.ids.windowTooltip).removeClass('show');
							}),
							nameSpan=jsl('span').createElement().html(json['blocks'][j]['links'][k]['html']||getTranslations('transEditThisLink')||'New bookmark'),
							parsUrl=jsl.parserUrl(json['blocks'][j]['links'][k]['href']),
							faviconImg=jsl('img').createElement({
								src:json['blocks'][j]['links'][k]['favicon_url']?json['blocks'][j]['links'][k]['favicon_url']:configs.domain+'/favicon.png?url='+parsUrl.protocol+'//'+parsUrl.host,
								alt:decode(json['blocks'][j]['links'][k]['title']||getTranslations('transEditThisLink')||'New bookmark')+' | '+json['blocks'][j]['links'][k]['href'],
								title:decode(json['blocks'][j]['links'][k]['title']||getTranslations('transEditThisLink')||'New bookmark')+' | '+json['blocks'][j]['links'][k]['href'],
								height:'16',
								width:'16',
								loading:'lazy'
							}).on('error',function(ev){
								ev.target.src=json.theme?translateStr(configs.html.errorFaviconDark):translateStr(configs.html.errorFavicon);
							}),
							editIcon=jsl('img').createElement({
								src:json.theme?translateStr(configs.html.editNameDark):translateStr(configs.html.editName),
								height:'16',
								width:'16',
								class:'pencil',
								alt:getTranslations('transEditThisLink')||'Edit this link',
								title:getTranslations('transEditThisLink')||'Edit this link',
								tl:'title:transEditThisLink',
								'data-num-link':'link-'+k,
								'data-num-block':'block-'+json['blocks'][j]['id']||j
							}).on('click',function(ev){
								//renderDashboard(JSON.parse(localStorage.dataBoard));
								//resizeDashboard(JSON.parse(localStorage.dataBoard));
								loader.start(/block-(\d+)/.exec(this.a.attributes['data-num-block'].value)[1]);
								var json=JSON.parse(localStorage.dataBoard)||json;
								editLink(ev.target,json);
							}).on('mousedown',function(ev){
								ev.preventDefault();
								return false;
							}),
							wrapLinkSpan=jsl('span').createElement({
								class:'wrap-link-span',
								'data-num':'wrap-link-'+k
							});
						linkA.append(faviconImg).append(nameSpan);
						wrapLinkSpan.append(linkA);
						if(!jsl.navi().mobile)
							wrapLinkSpan.append(editIcon);
						if(json.screenshot){
							var linkScreenshot=jsl('img').createElement({
								src:(configs.domain+'/_screenshot/'+btoa(json['blocks'][j]['links'][k]['href'])+'-pc.jpg'),
								class:'link-screenshot',
								'data-num':'link-'+k,
								alt:decode(json['blocks'][j]['links'][k]['title']||getTranslations('transEditThisLink')||'New bookmark')+' | '+json['blocks'][j]['links'][k]['href'],
								title:decode(json['blocks'][j]['links'][k]['title']||getTranslations('transEditThisLink')||'New bookmark')+' | '+json['blocks'][j]['links'][k]['href'],
								url:json['blocks'][j]['links'][k]['href'],
								onclick:"location='"+json['blocks'][j]['links'][k]['href']+"'",
								loading:'lazy',
								style:{
									display:'none'
								}
							}).on('load',function(ev){
								if((stopGo==undefined||stopGo==false)&&translateStr(configs.html.errorScreenshot)!=ev.target.src)
									jsl(ev.target).css('display','block');
							}).on('error',function(ev){
								jsl(ev.target).attr('src',translateStr(configs.html.errorScreenshot));
								jsl(ev.target).css('display','none');
							});
							linkScreenshot.a.onclick=function(ev){
								toGo(jsl(ev.target).attr('url'),ev);
								ev.preventDefault();
								return false;
							};
							wrapLinkSpan.append(linkScreenshot);
						}
						linkBlock.append(wrapLinkSpan);
					}
				}
				drag();
				inputBlockWrap.append(input).append(clAdd);
				inputBlock.append(inputBlockBack).append(inputBlockWrap);
				settingBlock.append(editBlock).append(openAll).append(plusBlock);
				titleBlock.append(nameBlock).append(inputName);
				if(!jsl.navi().mobile)
					titleBlock.append(settingBlock);
				wrapBlock.append(titleBlock).append(inputBlock).append(linkBlock).append(bottomBorder);
				block.append(wrapBlock);
				jsl('.colum[data-num="colum-'+columNumAppend+'"]').append(block);
			}
			jsl(configs.ids.body+' a').on('click',function(ev){
				var uri=ev.target.href==undefined?jsl(ev.target).parent().attr('href'):ev.target.href;
				toGo(uri,ev);
				ev.preventDefault();
				return false;
			});
		}
		jsl(configs.ids.blank).prop('scrollTop',scrollTop);
		loader.stop();
	}
	function toGo(uri,ev){
		if(stopGo==false)
			return;
		configs.openNewTab==true?window.open(uri):location=uri;
		ev.preventDefault();
		return false;
	}
	function addCategory(ev){
		openMenu(ev);
		jsl('.wrap-form').on('click',function(){
			jsl('.form input').on('focus');
		});
		jsl(configs.ids.popUp).css('display','flex').on('click',function(ev){
			loader.stop();
			if(ev.target==jsl(configs.ids.popUp).a)
				jsl(configs.ids.popUp).css('display','none');
		});
		jsl(configs.ids.popUp+' input[type="text"]').on('focus').val('');
	}
	function makeCounter(maxCount){
		var currentCount=-1;
		return {
			count:function(){
				if(currentCount>=maxCount){
					currentCount=0;
				}else{
					currentCount++;
				}
				return currentCount;
			}
		}
	}
	function refreshJson(json){
		var bodyOffsetWidth=jsl(configs.ids.body).css('offsetWidth'),
			json=json||JSON.parse(localStorage.dataBoard),
			arr={a:[],b:[]},
			columCount=Math.trunc(bodyOffsetWidth/Number(json.columMinWid))-1,
			mkc=makeCounter(columCount);
		if(json.blocks.length>0){
			var maxCount=json.blocks[0].parentColum;
			for(var i=0;i<json.blocks.length;i++){
				if(json.blocks[i].parentColum>maxCount){
					maxCount=json.blocks[i].parentColum;
				}
			}
		}else{
			var maxCount=0;
		}
		for(var i=0;i<json.blocks.length;i++){
			if(json.blocks[i].parentColum<=columCount&&json.blocks[i].parentColum<=maxCount){
				arr.a.push(json.blocks[i]);
			}else{
				arr.b.push(json.blocks[i]);
			}
		}
		arr.a.sort((a,b)=>a.parentColum-b.parentColum);
		arr.b.sort((a,b)=>a.parentColum-b.parentColum);
		if(bodyOffsetWidth<Number(json.countColum)*Number(json.columMinWid)||json.countColum-1<maxCount){
			json.blocks=[];
			for(var i=0;i<arr.a.length;i++){
				json.blocks.push(arr.a[i]);
			}
			for(var i=0;i<arr.b.length;i++){
				arr.b[i].parentColum=mkc.count();
				json.blocks.push(arr.b[i]);
			}
		}
		return json;
	}
	function resizeDashboard(json){
		if(json==undefined)
			json=JSON.parse(localStorage.dataBoard);
		var body=jsl(configs.ids.body),
			parrentElement=jsl(body).parent();
		parrentElement.css('width',window.innerWidth-expand+'px');
		json.columMinWid=Number(json.columMinWid)||45;
		json.maxColum=Math.trunc(parrentElement.css('offsetWidth')/Number(json.columMinWid));
		json.minColum=1;
		json.dragPoint=json.dragPoint;
		configs.lang=json.lang;
		json.theme=json.theme;
		json.screenshot=json.screenshot;
		json.showTooltip=json.showTooltip;
		json=refreshJson(json);
		renderDashboard(json);
		resizeColum(body,json);
	}
	function resizeColum(body,json){
		jsl(configs.ids.body).css('min-height',window.innerHeight-jsl(configs.ids.topNav).css('offsetHeight')+'px');
		if(body.css('offsetWidth')<Number(json.countColum)*Number(json.columMinWid)){
			jsl(configs.ids.body+' .colum').css({
				width:body.css('offsetWidth')/Math.floor(body.css('offsetWidth')/Number(json.columMinWid))+'px'
			}).forEach(function(e){
				if(e.innerHTML!=''){
					jsl(e).css('min-height','auto');
				}
			});
		}else{
			jsl(configs.ids.body+' .colum').css({
				width:'calc(100% / '+json.countColum+')',
				'min-height':window.innerHeight-jsl(configs.ids.topNav).css('offsetHeight')+'px'
			});
			if(jsl(configs.ids.body).css('offsetHeight')>window.innerHeight){
				jsl(configs.ids.body+' .colum').css({
					width:'calc(100% / '+json.countColum+')',
					'min-height':jsl(configs.ids.body).css('offsetHeight')+'px'
				});
			}else{
				jsl(configs.ids.body+' .colum').css({
					width:'calc(100% / '+json.countColum+')',
					'min-height':window.innerHeight-jsl(configs.ids.topNav).css('offsetHeight')+'px'
				});
			}
		}
	}
	function auth(that){
		jsl(that).childrenAll('input[name="login"]').attr('readonly','readonly').css('cursor','not-allowed');
		jsl(that).childrenAll('input[name="password"]').attr('readonly','readonly').css('cursor','not-allowed');
		jsl(that).childrenAll('input[name="submit"]').prop('disabled',true);
		var ajax=jsl.ajax({
				url:configs.domain+'/at.json',
				type:'POST',
				headers:{
					'Content-Type':'application/x-www-form-urlencoded',
				},
				onerror:function(e,res){
					var message=navigator.onLine?translateStr(configs.html.login):typeof e=='string'?e:'Bad reques!',
						div=jsl('div').createElement({
							style:{
								margin:'10px'
							}
						}).html(message);
					if(typeof e=='string')
						notificationShow(e,'error');
					loader.stop();
					clearInterval(clear);
					jsl(configs.ids.body).html('');
					jsl(configs.ids.body).append(div);
					offLine();
					jsl('form').childrenAll('input[name="login"]').eq(0).removeAttribute('readonly').css('cursor','');
					jsl('form').childrenAll('input[name="password"]').eq(0).removeAttribute('readonly').css('cursor','');
					jsl(that).childrenAll('input[name="submit"]').prop('disabled',false);
				},
				4:function(res){
					if(res.status!=200){
						return ajax.onerror(getTranslations('transErrorConnection')||'Error connection!',res);
					}
					if(jsl.isJSON(res.response)==false)
						return ajax.onerror(getTranslations('transBadResponse')||'Bad response!',res);
					jsl(configs.ids.body).html('');
					clearInterval(clear);
					if(res.response!=''){
						var currenJson=JSON.parse(res.response);
						if(currenJson.error){
							if(jsl(configs.ids.body+' input[type=checkbox]').length==0)
							({
								401:function(){
									var message=translateStr(configs.html.registration),
										conditions=jsl('label').createElement({
											class:'acept'
										}),
										check1=jsl('input').createElement({
											type:'checkbox',
											name:'acept',
											class:'acept'
										}),
										check=jsl('input').createElement({
											type:'checkbox',
											id:'check',
											name:'acept'
										}).on('change',function(ev){
											if(ev.target.checked){
												jsl(that).childrenAll('input[name="login"]').attr('readonly','readonly').css('cursor','not-allowed');
												jsl(that).childrenAll('input[name="password"]').attr('readonly','readonly').css('cursor','not-allowed');
											}
											if(!ev.target.checked){
												jsl(that).childrenAll('input[type="text"]').eq(0).removeAttribute('readonly').css('cursor','auto');
												jsl(that).childrenAll('input[type="password"]').eq(0).removeAttribute('readonly').css('cursor','auto');
											}
											check1.a.checked=ev.target.checked
										}),
										lab=jsl('label').createElement({
											for:'check'
										}).html(getTranslations('transIAccept')||'I agree to the <a href="'+configs.domain+'/tu" style="color:#2011AE" target="_blank">terms</a> of service.'),
										p=jsl('span').createElement(),
										sdfsd=jsl('div').createElement({
											style:{
												margin:'10px'
											}
										}).html(message);
									conditions.append(check).append(lab).append(p);
									jsl(configs.ids.body).append(sdfsd).append(conditions);
									if(jsl(configs.ids.topNav+' form').childrenAll('input[name=acept]').length==1)
										jsl(configs.ids.topNav+' form').append(check1);
									jsl(that).childrenAll('input[type="text"]').eq(0).removeAttribute('readonly').css('cursor','auto');
									jsl(that).childrenAll('input[type="password"]').eq(0).removeAttribute('readonly').css('cursor','auto');
									jsl(that).childrenAll('input[type="submit"]').prop('disabled',false);
									translateNodes();
									getManifest();
								},
								400:function(){
									var message=translateStr(configs.html.login),
										sdfsd=jsl('div').createElement({
											style:{
												margin:'10px'
											}
										}).html(message);
									jsl(configs.ids.body).append(sdfsd);
									jsl(that).childrenAll('input[type="text"]').eq(0).removeAttribute('readonly').css('cursor','auto');
									jsl(that).childrenAll('input[type="password"]').eq(0).removeAttribute('readonly').css('cursor','auto');
									jsl(that).childrenAll('input[type="submit"]').prop('disabled',false);
								}
							})[currenJson.error]();
						}else{
							jsl(configs.ids.topNav).html('');
							location.reload();
						}
					}
				}
			},jsl(that).formToObject()),
			clear=setInterval(function(){
				jsl(configs.ids.body).html(jsl(configs.ids.body).html()+'.');
			},30);
		jsl(configs.ids.body).html('');
	}
	function blurCon(value,data){
		var json=JSON.parse(localStorage.dataBoard);
		updateData(json,{
			[data]:value,
			data:data
		},'userData');
	}
	function changeMinWid(that){
		var json=JSON.parse(localStorage.dataBoard),
			val=that.value;
		json.columMinWid=Number(val)||75;
		json.timestamp=Date.now();
		json.data=saveHtml();
		localStorage.dataBoard=JSON.stringify(json);
		configs.dataBoard=json;
		resizeDashboard(json);
	}
	function changeCountColum(that){
		var json=JSON.parse(localStorage.dataBoard),
			val=that.value;
		if(Number(val)>Number(json.maxColum))val=json.maxColum;
		if(Number(val)<Number(json.minColum))val=json.minColum;
		that.value=val;
		json.countColum=Number(val);
		json.timestamp=Date.now();
		json.data=saveHtml();
		localStorage.dataBoard=JSON.stringify(json);
		configs.dataBoard=json;
		resizeDashboard(json);
	}
	function changeTheme(that){
		var json=JSON.parse(localStorage.dataBoard);
		json.theme=that.checked;
		json.timestamp=Date.now();
		json.data=saveHtml();
		localStorage.dataBoard=JSON.stringify(json);
		configs.dataBoard=json;
		blurCon(that.checked,'changeTheme');
	}
	function changeShowTooltip(that){
		var json=JSON.parse(localStorage.dataBoard);
		json.showTooltip=that.checked;
		json.timestamp=Date.now();
		json.data=saveHtml();
		localStorage.dataBoard=JSON.stringify(json);
		configs.dataBoard=json;
		blurCon(that.checked,'showTooltip');
	}
	function changeScreenshot(that){
		var json=JSON.parse(localStorage.dataBoard);
		json.screenshot=that.checked;
		json.timestamp=Date.now();
		json.data=saveHtml();
		localStorage.dataBoard=JSON.stringify(json);
		configs.dataBoard=json;
		blurCon(that.checked,'changeScreenshot');
	}
	function changeBorders(that){
		var json=JSON.parse(localStorage.dataBoard);
		json.borders=that.value;
		json.timestamp=Date.now();
		json.data=saveHtml();
		localStorage.dataBoard=JSON.stringify(json);
		configs.dataBoard=json;
		blurCon(that.value,'changeBorders');
	}
	function changeFontSize(that){
		var json=JSON.parse(localStorage.dataBoard);
		json.fontSize=that.value;
		json.timestamp=Date.now();
		json.data=saveHtml();
		localStorage.dataBoard=JSON.stringify(json);
		configs.dataBoard=json;
		blurCon(that.value,'changeFontSize');
	}
	function changeSearchEngine(that){
		var json=JSON.parse(localStorage.dataBoard),
			val=that.value;
		json.searchService=val;
		json.timestamp=Date.now();
		json.data=saveHtml();
		localStorage.dataBoard=JSON.stringify(json);
		configs.dataBoard=json;
		try{
			jsl(configs.ids.topNav).children('.search').eq(0).prop('placeholder',getTranslations('transSearchInputPlac')+' '+(getTranslations('transSearchInputPlac')&&jsl(configs.ids.topNav).children('.searchservice').eq(0).children('option').eq(jsl(configs.ids.topNav).children('.searchservice').eq(0).prop('selectedIndex')).html()));
		}catch(e){}
	}
	function changeOpenNewTab(that){
		var json=JSON.parse(localStorage.dataBoard);
		json.openNewTab=that.checked;
		json.timestamp=Date.now();
		json.data=saveHtml();
		localStorage.dataBoard=JSON.stringify(json);
		configs.dataBoard=json;
		blurCon(that.checked,'openNewTab');
	}
	function changeFlow(that){
		var json=JSON.parse(localStorage.dataBoard);
		json.dragPoint=that.checked;
		json.timestamp=Date.now();
		json.data=saveHtml();
		localStorage.dataBoard=JSON.stringify(json);
		configs.dataBoard=json;
		blurCon(that.checked,'dragPoint');
	}
	function changeLang(that){
		var json=JSON.parse(localStorage.dataBoard||'{}'),
			val=that.value||localStorage.lang;
		json.lang=val;
		configs.lang=val;
		json.lang=val;
		json.timestamp=Date.now();
		json.data=saveHtml();
		localStorage.dataBoard=JSON.stringify(json);
		configs.dataBoard=json;
		translateNodes(val);
		setTimeout(getManifest,100);
	}
	function openMenu(){
		var arr=jsl('.menu').css('display')=='block'?['','removeClass','none']:['light','addClass','block'];
		jsl('.summary').css('color',arr[0])[arr[1]]('background');
		jsl('.menu').css('display',arr[2]);
		if(arr[2]=='block'){
			jsl('body').addClass('edit');
			stopGo=false;
		}
		if(arr[2]=='none'){
			jsl('body').removeClass('edit');
			setTimeout(function(){stopGo=true;},100);
		}
	}
	function addEvents(){
		jsl('.search-block input').on('input',function(ev){
			searchJson(ev.target.value);
		}).on('keyup',function(ev){
			if(ev.keyCode==13){
				if(jsl('.search-block input').val()!=''){
					if(validURL(jsl('.search-block input').val())){
						if(/^https:\/\/|http:\/\//.test(jsl('.search-block input').val())){
							location=jsl('.search-block input').val();
						}else{
							location='http://'+jsl('.search-block input').val();
						}
					}else{
						toGo(jsl('.searchservice').val()+jsl('.search-block input').val(),ev);
					}
				}
			}
			searchJson(ev.target.value);
		}).on('keydown',function(ev){
			if(ev.keyCode==27){
				jsl('.search-block input').val('');
			}
			searchJson(ev.target.value);
		});
		jsl('.logo-block a').on('click',function(ev){
			location.reload();
			ev.preventDefault();
			return false;
		});
		jsl('.cancel').on('click',function(ev){
			jsl('.search-block input').val('');
			renderDashboard();
			resizeDashboard();
			ev.target.style.visibility='hidden';
			jsl('.search-block input').on('focus');
		});
		jsl('.summary').on('click',function(ev){
			openMenu(ev.target);
		});
		jsl('.colum-min-width').on('input',function(ev){
			changeMinWid(ev.target);
		});
		jsl('.colum-min-width').on('blur',function(ev){
			blurCon(ev.target.value,'cangeMinWidth');
		});
		jsl('.count-colum').on('change',function(ev){
			changeCountColum(ev.target);
		});
		jsl('.count-colum').on('blur',function(ev){
			blurCon(ev.target.value,'changeColum');
		});
		jsl('.searchservice').on('change',function(ev){
			changeSearchEngine(ev.target);
		});
		jsl('.searchservice').on('blur',function(ev){
			blurCon(ev.target.value,'changeSearchEngine');
		});
		jsl('.change-flow').on('change',function(ev){
			changeFlow(ev.target);
		});
		jsl('.theme').on('change',function(ev){
			changeTheme(ev.target);
		});
		jsl('.screenshot').on('change',function(ev){
			changeScreenshot(ev.target);
		});
		jsl('.open-new-tab').on('change',function(ev){
			changeOpenNewTab(ev.target);
		});
		jsl('.show-tooltip').on('change',function(ev){
			changeShowTooltip(ev.target);
		});
		jsl('input[name="borders"]').on('change',function(ev){
			changeBorders(ev.target);
		});
		jsl('input[name="font-size"]').on('change',function(ev){
			changeFontSize(ev.target);
		});
		jsl('.add-category').on('click',function(ev){
			addCategory(ev.target);
		});
		jsl('.loginout').on('click',function(ev){
			clearCash(clearSess);
		});
		jsl('.form input').on('keyup',function(ev){
			appendCategory(ev);
		});
		jsl('.form input').on('keydown',function(ev){
			if(ev.keyCode==27){
				jsl(configs.ids.popUp).css('display','none');
			}
		});
		jsl('form').on('submit',function(ev){
			ev.preventDefault();
			return false;
		});
	}
	function loadHtml(autorized){
		if(autorized){
			jsl(configs.ids.topNav).html(translateStr(configs.html.topNavLog));
			jsl(configs.ids.popUp).html(translateStr(configs.html.popUp));
			jsl(configs.ids.confirm).html(translateStr(configs.html.updateButton));
			addEvents();
			startPromotion();
			translateNodes(configs.lang);
		}else{
			jsl(configs.ids.holder+' .welcome-wrap').css('display','block');
			jsl(configs.ids.blank).css('background','');
			jsl(configs.ids.topNav).html(translateStr(configs.html.topNav));
			setTimeout(function(){
				jsl(configs.ids.body).html(translateStr(configs.html.main));
			},100);
			translateNodes();
			getManifest();
			offLine();
		}
	}
	function offLine(){
		if(!navigator.onLine){
			jsl(configs.ids.topNav).html(translateStr(configs.html.topNav));
			jsl(configs.ids.topNav).children('.offline').css('display','flex');
			jsl(configs.ids.topNav).children('.offline button').on('click',function(){
				location.reload();
			});
			setInterval(function(){
				if(navigator.onLine){
					navigator.serviceWorker.getRegistrations().then(function(registrations){
						caches.keys().then(function(keyList){
							return Promise.all(keyList.map(function(key){
								return caches.delete(key);
							}));
						});
						for(var registration of registrations){
							registration.unregister();
						}
					});
					caches.delete(configs.manifestExt.version).then(function(boolean){});
					location.reload();
				}
			},2e3);
		}
	}
	function startPromotion(){
		if(configs.deferredPrompt!=undefined){
			jsl(configs.ids.topNav+' [name="installApp"]').css('display','flex');
			jsl(configs.ids.topNav+' [name="installApp"] button').on('click',function(){
				configs.deferredPrompt.prompt();
			});
			jsl(configs.ids.topNav+' a[name="installApp"]').on('click',function(){
				configs.deferredPrompt.prompt();
			});
		}else{
			jsl(configs.ids.topNav+' [name="installApp"]').css('display','none');
		}
		if(configs.appType=='extention'){
			jsl(configs.ids.topNav+' .promote-extension').css('display','none');
			jsl(configs.ids.topNav+' #langs').css('display','none');
		}
		jsl(configs.ids.topNav+' .promote-extension button').on('click',function(){
			window.open('https://chrome.google.com/webstore/detail/'+configs.chromeId);
		});
	}
	function ping(callback){
		fetch('/_locales/en/messages.json?'+Date.now()).then(function(res){
			if(res.headers.get('Content-Type')=='application/json'){
				if(typeof callback.online=='function'){
					callback.online();
				}
			}else{
				if(typeof callback.offline=='function'){
					callback.offline();
				}
			}
		}).catch(function(){
			if(typeof callback.offline=='function'){
				callback.offline();
			}
		});
	}
	function presentation(){
		if(!localStorage.dataBoard)
			return;
		var json=JSON.parse(localStorage.dataBoard);
		for(var i=0;i<json.presentation.length;i++){
			jsl('[name="'+json.presentation[i]+'-presentation"]').css('display','block').on('click',function(ev){
				var json=JSON.parse(localStorage.dataBoard);
				ev.target.name=jsl(ev.target).attr('name');
				jsl('[name="'+ev.target.name+'"]').css('display','none');
				switch(ev.target.name){
					case'logo-presentation':
						if(json.presentation.indexOf('logo')>-1)
							json.presentation.splice(json.presentation.indexOf('logo'),1);
					break;
					case'menu-presentation':
						if(json.presentation.indexOf('menu')>-1)
							json.presentation.splice(json.presentation.indexOf('menu'),1);
					break;
					case'menu-add-presentation':
						if(json.presentation.indexOf('menu-add')>-1)
							json.presentation.splice(json.presentation.indexOf('menu-add'),1);
					break;
				}
				updateData(json,{},'sinhronize');
			});
		}
	}
	function main(){
		var currenJson;
		configs.appType=this.appType;
		loader.start();
		if(localStorage.dataBoard){
			loadHtml(true);
			currenJson=JSON.parse(localStorage.dataBoard);
			if(currenJson.blocks.length==0){
				jsl(configs.ids.body).html(translateStr(configs.html.mainLog));
			}
			if(currenJson.theme!=undefined){
				if(currenJson.theme){
					jsl('body').attr('id','dark');
				}else{
					jsl('body').attr('id','light');
				}
			}
			setTimeout(function(){
				renderDashboard(currenJson);
				resizeDashboard(currenJson);
			},100);
		}else{
			loader.stop();
		}
		if(localStorage.data!=null&&localStorage.dataBoard!=undefined&&JSON.parse(localStorage.dataBoard).blocks.length){
			jsl(configs.ids.blank).html(localStorage.data);
			addEvents();
		}
		var ajax=jsl.ajax({
			url:configs.domain+'/sd.json',
			type:'POST',
			headers:{
				'Content-Type':'application/json'
			},
			onerror:function(e){
				var pnd={
					online:function(){
						navigator.serviceWorker.getRegistrations().then(function(registrations){
							caches.keys().then(function(keyList){
								return Promise.all(keyList.map(function(key){
									return caches.delete(key);
								}));
							});
							for(var registration of registrations){
								registration.unregister();
							}
						});
						caches.delete(configs.manifestExt.version).then(function(boolean){});
						if(localStorage.offline=='true'){
							localStorage.removeItem('offline');
							location.reload();
						}
					},
					offline:function(){
						jsl(configs.ids.holder+' .welcome-wrap').css('display','block');
						jsl(configs.ids.blank).css('background','');
						jsl(configs.ids.topNav).html(translateStr(configs.html.topNav));
						if(localStorage.dataBoard==undefined){
							setTimeout(function(){
								translateNodes();
							},100);
						}
						getManifest();
						jsl(configs.ids.topNav).children('.offline').css('display','flex');
						jsl(configs.ids.topNav).children('.offline button').on('click',function(){
							location.reload();
						});
						localStorage.offline=true;
					}
				};
				ping(pnd);
				setInterval(function(){
					ping(pnd);
				},2e4);
				if(localStorage.dataBoard==null){
					jsl(configs.ids.body).html(translateStr(configs.html.main));
				}else{
					renderDashboard(JSON.parse(localStorage.dataBoard));
					resizeDashboard(JSON.parse(localStorage.dataBoard));
					jsl(function(){
						if(localStorage.dataBoard){
							resizeDashboard(JSON.parse(localStorage.dataBoard));
						}
					},['resize']);
				}
				if(typeof e=='string')
					notificationShow(e,'error');
				loader.stop();
			},
			4:function(res){
				if(res.status!=200){
					return ajax.onerror(getTranslations('transErrorConnection')||'Error connection!');
				}
				if(res.response==''){
					if(jsl.isJSON(localStorage.dataBoard)==false)
						return ajax.onerror(getTranslations('transBadResponse')||'Bad response!');
					var currenJson=JSON.parse(localStorage.dataBoard),
						serverJson=JSON.parse(localStorage.dataBoard);
				}else{
					if(jsl.isJSON(res.response)==false)
						return ajax.onerror(getTranslations('transBadResponse')||'Bad response!');
					var currenJson=JSON.parse(res.response),
						serverJson=JSON.parse(res.response);
				}
				if(serverJson.error){
					({
						530:function(){
							loadHtml(false);
							if(localStorage.dataBoard!=null)
								jsl(configs.ids.body).html(translateStr(configs.html.bodySoWr));
							localStorage.removeItem('dataBoard');
							for (var name in localStorage){
								if(name!='appVersion'){
									//localStorage.removeItem(name);
								}
							}
							var counter=0,
								clear=setInterval(function(){
									counter++;
									if(counter>1000){
										clearInterval(clear);
									}
									jsl(configs.ids.topNav).children('form').eq(0).on('submit',function(ev){
										auth(this.a);
										ev.preventDefault();
										return false;
									});
									jsl(configs.ids.topNav).children('.social .fb').eq(0).on('click',function(ev){
										authFb(ev);
									});
									jsl(configs.ids.topNav).children('.social .go').eq(0).on('click',function(ev){
										authGo(ev);
									});
									jsl(configs.ids.topNav).children('.social .app').eq(0).on('click',function(ev){
										startPromotion();
									});
									if(jsl(configs.ids.topNav).children('form').length==1){
										clearInterval(clear);
									}
								});
						},
						400:function(){
							notificationShow('Bad reques!','error');
						}
					})[serverJson.error]();
				}else{
					loadHtml(true);
					addEvents();
					if(res.response!=localStorage.dataBoard){
						if(localStorage.dataBoard==null||localStorage.dataBoard==''){
							currenJson=serverJson;
							localStorage.dataBoard=JSON.stringify(currenJson);
							if(currenJson.blocks.length==0)
								jsl(configs.ids.body).html(translateStr(configs.html.mainLog));
							configs.dataBoard=currenJson;
							location.reload();
						}else{
							var clientJson=JSON.parse(localStorage.dataBoard),
								comparison=function(){
									return(JSON.stringify(serverJson.blocks)==JSON.stringify(clientJson.blocks)&&serverJson.columMinWid==clientJson.columMinWid&&serverJson.countColum==clientJson.countColum&&serverJson.dragPoint==clientJson.dragPoint&&serverJson.openNewTab==clientJson.openNewTab&&serverJson.showTooltip==clientJson.showTooltip&&serverJson.screenshot==clientJson.screenshot&&serverJson.searchService==clientJson.searchService&&serverJson.theme==clientJson.theme)
								};
							if(clientJson.hash!=serverJson.hash){
								clearCash();
								loader.start();
								localStorage.clear();
								notificationShow(getTranslations('transLoadData')||'Load data.','warning');
								location.reload();
							}
							if(Number(serverJson.timestamp)>Number(clientJson.timestamp)){
								if(comparison()){
									loader.start();
									notificationShow(getTranslations('transLoadData')||'Load data.','warning');
									setTimeout(function(){
										localStorage.clear();
										location.reload();
									},3e3);
									clearCash(clearSess);
								}
								jsl(configs.ids.confirm+' .message').html(translateStr(configs.html.syncToPc));
								if(localStorage.dontUpdate){
									if(localStorage.dontUpdate!=serverJson.dataVersionId){
										jsl(configs.ids.confirm).css('display','block');
									}
								}else{
									jsl(configs.ids.confirm).css('display','block');
								}
								jsl(configs.ids.confirm+' button.up').on('click', function(){
									currenJson=serverJson;
									localStorage.clear();
									jsl(configs.ids.confirm).css('display','none');
									notificationShow(getTranslations('transLoadData')||'Load data.','warning');
									loader.start();
									setTimeout(function(){
										location.reload();
									},3e3);
								});
								jsl(configs.ids.confirm+' button.down').on('click', function(){
									localStorage.dontUpdate=serverJson.dataVersionId;
									jsl(configs.ids.confirm).css('display','none');
								});
								translateNodes();
								getManifest();
							}
							if(Number(serverJson.timestamp)<Number(clientJson.timestamp)){
								if(comparison()){
									loader.start();
									notificationShow(getTranslations('transLoadData')||'Load data.','warning');
									setTimeout(function(){
										localStorage.clear();
										location.reload();
									},3e3);
									clearCash(clearSess);
								}
								jsl(configs.ids.confirm+' .message').html(translateStr(configs.html.syncToServ));
								if(localStorage.dontUpdate){
									if(localStorage.dontUpdate!=clientJson.dataVersionId){
										jsl(configs.ids.confirm).css('display','block');
									}
								}else{
									jsl(configs.ids.confirm).css('display','block');
								}
								jsl(configs.ids.confirm+' button.up').on('click', function(){
									currenJson=clientJson;
									updateData(currenJson,{},'sinhronize');
									jsl(configs.ids.confirm).css('display','none');
									notificationShow(getTranslations('transLoadData')||'Load data.','warning');
									loader.start();
									setTimeout(function(){
										location.reload();
									},3e3);
								});
								jsl(configs.ids.confirm+' button.down').on('click', function(){
									localStorage.dontUpdate=clientJson.dataVersionId;
									jsl(configs.ids.confirm).css('display','none');
								});
								translateNodes();
								getManifest();
							}
							if(Number(serverJson.timestamp)==Number(clientJson.timestamp)){
								currenJson=serverJson;
								localStorage.dataBoard=JSON.stringify(currenJson);
								configs.dataBoard=currenJson;
								renderDashboard(currenJson);
								resizeDashboard(currenJson);
								jsl(configs.ids.confirm).css('display','none');
								saveHtml();
							}
						}
					}
					jsl(function(){
						if(localStorage.dataBoard){
							resizeDashboard(JSON.parse(localStorage.dataBoard));
						}
					},['resize']);
				}
				loader.stop();
				getManifest();
			}
		},localStorage.dataBoard);
		setTimeout(function(){
			try{
				jsl(configs.ids.topNav).children('.search').eq(0).prop('placeholder',getTranslations('transSearchInputPlac')+' '+(getTranslations('transSearchInputPlac')&&jsl(configs.ids.topNav).children('.searchservice').eq(0).children('option').eq(jsl(configs.ids.topNav).children('.searchservice').eq(0).prop('selectedIndex')).html()));
			}catch(e){}
			jsl(configs.ids.blank).css('background','');
			startPromotion();
			presentation();
		},100);
		expandFn();
		sw();
		jsl.on('keydown',function(ev){
			if(ev.keyCode==8&&ev.target==document.body){
				jsl('.search-block input').on('focus');
				ev.preventDefault();
				return false;
			}
		}).on('mousemove',function(ev){
			mouseShowHandler(ev);
		}).on('mouseup',function(ev){
			if(ev.target.closest('.details')==null){
				if(jsl('.menu').a!=null){
					if(jsl('.menu').css('display')=='block'){
						jsl('.title-block .open-all').css('display','');
						jsl('.title-block .pencil').css('display','');
						jsl('.title-block .plus').css('display','');
						jsl('.link-block .pencil').css('display','');
						jsl('body').removeClass('edit');
						jsl('.menu').css('display','none');
						jsl('.summary').removeClass('background').css('color','');
						setTimeout(function(){stopGo=true;},100);
					}
				}
			}
		});
		var menu=document.querySelector('.menus'),
			showMenu=function(x,y){},
			hideMenu=function(){},
			onMouseDown=function(ev){
				hideMenu();
				document.removeEventListener('mousedown',onMouseDown);
			};
		document.addEventListener('contextmenu',function(ev){
			ev.preventDefault();
			showMenu(ev.pageX,ev.pageY);
			document.addEventListener('mousedown',onMouseDown,false);
		},false);
		document.onkeydown=function(ev){
			if(ev.ctrlKey&&ev.shiftKey&&ev.keyCode=='I'.charCodeAt(0)){
				return false;
			}
			if(ev.ctrlKey&&ev.shiftKey&&ev.keyCode=='J'.charCodeAt(0)){
				return false;
			}
			if(ev.ctrlKey&&ev.keyCode=='U'.charCodeAt(0)){
				return false;
			}
		}
	}
	function sw(){
		if('serviceWorker' in navigator&&location.origin==configs.domain){
			navigator.serviceWorker.register('/sw.js',{
				scope:'./'
			}).then(function(reg){
				reg.onupdatefound=function(){
					var installingWorker=reg.installing;
					switch(installingWorker.state){
						case 'installing':
							console.log('%cSW installing','color:black;background-color:yellow;');
						break;
						case 'installed':
							console.log('%cSW installed','color:black;background-color:yellow;');
						break;
						case 'activating':
							console.log('%cSW activating','color:black;background-color:yellow;');
						break;
						case 'activated':
							console.log('%cSW activated','color:black;background-color:yellow;');
						break;
						case 'redundant':
							console.log('%cSW redundant','color:black;background-color:yellow;');
						break;
					}
					installingWorker.onstatechange=function(){
						switch(installingWorker.state){
							case 'installing':
								console.log('%cSW installing','color:black;background-color:yellow;');
							break;
							case 'installed':
								console.log('%cSW installed','color:black;background-color:yellow;');
							break;
							case 'activating':
								console.log('%cSW activating','color:black;background-color:yellow;');
							break;
							case 'activated':
								console.log('%cSW activated','color:black;background-color:yellow;');
							break;
							case 'redundant':
								console.log('%cSW redundant','color:black;background-color:yellow;');
							break;
						}
					};
				};
			}).catch(function(error){
				console.log('%cSW registration faild','color:black;background-color:yellow;');
			});
		}
		window.addEventListener('beforeinstallprompt',function(ev){
			configs.deferredPrompt=ev;
			startPromotion();
		});
		window.addEventListener('appinstalled',function(ev){
			configs.deferredPrompt=undefined;
			startPromotion();
		});
	}
	(function(){
		loader={
			start:function(num){
				jsl(configs.ids.body).css('background','rgba(0,0,0,0)');
				jsl(configs.ids.topNav).css({
					opacity:.2,
					background:'rgba(0,0,0,0)'
				});
				jsl('body').addClass('edit');
				jsl('.block[data-num]').css('opacity','.2');
				jsl('.block[data-num="block-'+num+'"]').addClass('edit');
			},
			stop:function(){
				jsl(configs.ids.body).css('background','');
				jsl(configs.ids.topNav).css({
					opacity:'',
					background:''
				});
				jsl('body').removeClass('edit');
				if(jsl('.block[data-num]').length>0){
					jsl('.block[data-num]').forEach(function(el){
						jsl(el).removeClass('edit');
						jsl(el).css({
							opacity:'',
							background:''
						});
					});
				}
			}
		};
		if(typeof chrome=='undefined'||typeof chrome.i18n=='undefined'||chrome.i18n.getMessage=='undefined'){
			if(typeof chrome=='undefined')
				window.chrome={};
			if(typeof chrome.i18n=='undefined')
				chrome.i18n={
					getMessage:function(){
						return undefined;
					}
				};
		}
		if(chrome.extension){
			jsl(main.bind({appType:'extention'}),['load']);
		}else{
			jsl(main.bind({appType:'site'}),['load']);
		}
	})();
})();