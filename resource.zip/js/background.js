var tabsList=[];
function get(f){
	chrome.storage.local.get(['tabsList'],function(res){
		if(res.tabsList){
			f(JSON.parse(res.tabsList));
		}else{
			f([]);
		}
	});
}
function add(n){
	get(function(res){
		var dat=res.tabsList?JSON.parse(res.tabsList):[];
		dat.push(n);
		chrome.storage.local.set({tabsList:JSON.stringify(dat)});
	});
}
function remove(n){
	get(function(res){
		var dat=res?res:[];
		if(dat.indexOf(n)!=-1){
			dat.splice(dat.indexOf(n),1);
			chrome.storage.local.set({tabsList:JSON.stringify(dat)});
		}
	});
}
function isNewTab(url,id){
	if(url){
		var newTab=url.match(/^([a-z]+):\/\/([a-z-]+)\/?$/);
		var aboutBlank=url.match(/^(about):(blank)[#blocked]{0,}$/);
		var googleNewTab=url.match(/https:\/\/www\.google\.com\/_\/chrome\/newtab/);
		var webApp=url.match(/^chrome-extension:\/\/[a-z]+\/html\/newtab\.html$/);
		if(newTab!=null){
			if((newTab[1]=='chrome'||newTab[1]=='vivaldi')&&(newTab[2]=='new-tab-page'||newTab[2]=='new-tab-page-third-party')){
				return true;
			}
			if((newTab[1]=='chrome'||newTab[1]=='vivaldi')&&(newTab[2]=='newtab')){
				return true;
			}
		}
		if(aboutBlank!=null){
			if(aboutBlank[1]=='about'&&aboutBlank[2]=='blank'){
				return true;
			}
		}
		if(googleNewTab!=null){
			return true;
		}
		if(webApp!=null){
			return true;
		}
		return false;
	}
}
chrome.runtime.onInstalled.addListener(function(){
	chrome.tabs.query({},function(tabs){
		tabs.forEach(function(tab){
			if(isNewTab(tab.url,tab.id)){
				get(function(tabsList){
					if(tabsList.indexOf(tab.id)==-1){
						chrome.tabs.get(tab.id,function(res){
							if(!chrome.runtime.lastError){
								tabsList.splice(tabsList.indexOf(tab.id),1);
								chrome.tabs.remove(tab.id);
							}
						});
					}
				});
			}
		});
	});
	if(chrome.runtime.getManifest().version_name.split(' ')[1]=='critical'){
		chrome.tabs.create({
			url:'chrome://newtab/'
		});
	}
	chrome.contextMenus.create({
		id:'opennewtab',
		title:chrome.i18n.getMessage('transOpenNewTab')||'Open New Tab',
		contexts:[
			'action'
		]
	});
	chrome.contextMenus.create({
		id:'opensite',
		title:chrome.i18n.getMessage('transLogo')||'Open on the website',
		contexts:[
			'action'
		]
	});
	chrome.contextMenus.create({
		id:'openstore',
		title:chrome.i18n.getMessage('transDownloadGoogle')||'Open Chrome Web Store',
		contexts:[
			'action'
		]
	});
});
chrome.runtime.onUpdateAvailable.addListener(function(ev){
	chrome.runtime.reload();
});
chrome.runtime.setUninstallURL('https://chrome.google.com/webstore/detail/'+chrome.runtime.id,function(){
	chrome.tabs.query({},function(tabs){
		tabs.forEach(function(tab){
			if(isNewTab(tab.url,tab.id)){
				get(function(tabsList){
					if(tabsList.indexOf(tab.id)==-1){
						chrome.tabs.get(tab.id,function(res){
							if(!chrome.runtime.lastError){
								tabsList.splice(tabsList.indexOf(tab.id),1);
								chrome.tabs.remove(tab.id);
							}
						});
					}
				});
			}
		});
	});
});
chrome.tabs.onCreated.addListener(function(tab){
	if(isNewTab(tab.pendingUrl,tab.id)){
		tabsList.push(tab.id);
		add(tab.id);
		console.log({
			event:'onCreated',
			tab:tab,
			tabId:tab.id,
			tabsList:tabsList
		});
	}
});
chrome.tabs.onActivated.addListener(function(activeInfo){
	chrome.tabs.get(activeInfo.tabId,function(tab){
		var url=tab.url||tab.pendingUrl;
		if(isNewTab(url,tab.id)){
			console.log({
				event:'onActivated',
				tab:tab,
				url:url,
				tabId:tab.id,
				tabUrl:tab.url,
				tabsList:tabsList
			});
			get(function(tabsList){
				if(tabsList.indexOf(tab.id)==-1){
					/*chrome.tabs.update(tab.id,{
						url:chrome.runtime.getURL('/html/newpage.html')
					});*/
				}
			});
		}
	});
});
chrome.tabs.onUpdated.addListener(function(tabId,changeInfo,tab){
	if(!isNewTab(tab.url||tab.pendingUrl,tabId)){
		if(tabsList.indexOf(tabId)>=0){
			tabsList.splice(tabsList.indexOf(tabId),1);
		}
	}else{
		if(tabsList.indexOf(tabId)==-1){
			tabsList.push(tabId)
		}
	}
});
chrome.tabs.onRemoved.addListener(function(tabId){
	if(tabsList.indexOf(tabId)!=-1){
		tabsList.splice(tabsList.indexOf(tabId),1);
		remove(tabId);
		console.log({
			event:'onRemoved',
			tabId:tabId,
			tabsList:tabsList
		});
	}
});
chrome.action.onClicked.addListener(function(){
	chrome.tabs.create({
		url:'chrome://newtab/'
	});
});
chrome.contextMenus.onClicked.addListener(function(ev){
	if(ev.menuItemId=='openstore'){
		chrome.tabs.create({
			url:'https://chrome.google.com/webstore/detail/'+chrome.runtime.id
		});
	}
	if(ev.menuItemId=='opensite'){
		chrome.tabs.create({
			url:chrome.runtime.getManifest().homepage_url
		});
	}
	if(ev.menuItemId=='opennewtab'){
		chrome.tabs.create({
			url:'chrome://newtab/'
		});
	}
});