var version='6.3.0.3';
(l=localStorage.dataBoard)&&(d=document,d.body.id=JSON.parse(l).theme?'dark':'light',d.body.style.background=JSON.parse(l).theme?'#333':'#ddd');
['/js/conf.js?v='+version,'/js/main.js?v='+version].forEach(function(el){
	var script=document.createElement('script');
	script.crossorigin="anonymous";
	script.src=el;
	script.setAttribute('crossorigin','anonymous');
	script.setAttribute('defer','');
	document.head.appendChild(script);
});
