chrome.tabs.create({
	url:'chrome://newtab/'
});
window.close();